# VINTAGE TOUCH — Technical Specification

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `react` | `^18.3.0` | UI framework |
| `react-dom` | `^18.3.0` | React DOM renderer |
| `gsap` | `^3.12.0` | Core animation engine (ScrollTrigger, SplitText plugins) |
| `lenis` | `^1.1.0` | Smooth scroll with inertia |
| `three` | `^0.170.0` | WebGL scene for Spatial Z-Gallery |
| `@react-three/fiber` | `^8.17.0` | React renderer for Three.js |
| `@react-three/drei` | `^9.114.0` | R3F helpers (useTexture, OrthographicCamera) |
| `imagesloaded` | `^5.0.0` | Image preload gating for WebGL |
| `tailwindcss` | `^3.4.0` | Utility-first styling |
| `@tailwindcss/typography` | `^0.5.0` | Typography utilities |
| `typescript` | `^5.6.0` | Type safety |
| `vite` | `^6.0.0` | Build tool |
| `@vitejs/plugin-react` | `^4.3.0` | Vite React plugin |

**Dev Dependencies**: `autoprefixer`, `postcss`, `@types/three`, `@types/imagesloaded`

**Fonts**: GT Super Display (Adobe Fonts / self-hosted) + Neue Montreal (Pangram Pangram / fallback to Inter). Loaded via `@font-face` in CSS.

---

## Component Inventory

### Layout

| Component | Source | Notes |
|-----------|--------|-------|
| `Navbar` | Custom | Fixed 80px header. Scroll-direction-aware hide/show via translateY. Backdrop blur activates after 100px scroll. |
| `CustomCursor` | Custom | Two-layer system: 10px red dot + SVG trail. Listens to mousemove, hides native cursor. Trail uses RAF loop with bezier path interpolation. |

### Sections

| Component | Source | Notes |
|-----------|--------|-------|
| `Hero` | Custom | 3D CSS cube with `preserve-3d`. 4 faces, 150px height, 800px max-width. Hover triggers 180° Y rotation. GSAP timeline loops text swaps every 4s. |
| `Marquee` | Custom | Pure CSS `translateX` infinite loop. 20px vertical padding, red background. Duplicated content for seamless loop. |
| `NostalgiaTour` | Custom | Two-column 40/60 split. Image uses Cinematic Wipe Reveal (clip-path + scale). |
| `SpatialGallery` | Custom (Three.js) | R3F `<Canvas>` with OrthographicCamera. 3 `<ImagePlane>` meshes on Z-axis. Scroll progress drives camera Z. Mouse parallax via uniforms. |
| `ProductGrid` | Custom | 3-column CSS Grid. Hover logic: siblings dim to opacity 0.4, hovered card scales 1.02x. |
| `HeritageCounter` | Custom | 3 RollingDigit instances (01, 02, 03). Each digit is a vertical strip of 0-9 translated by GSAP. |
| `Footer` | Custom | 4-column grid on light-grey background. Large CTA button with hover inversion. |

### Reusable Components

| Component | Source | Used By |
|-----------|--------|---------|
| `RollingDigit` | Custom | `HeritageCounter` |
| `ImagePlane` | Custom (R3F) | `SpatialGallery` |
| `CinematicReveal` | Custom | `NostalgiaTour` |
| `Trail` | Custom (vanilla JS) | `CustomCursor` |

### Hooks

| Hook | Purpose |
|------|---------|
| `useLenis` | Initialize Lenis, sync with GSAP ScrollTrigger ticker |

---

## Animation Implementation

| Animation | Library | Approach | Complexity |
|-----------|---------|----------|------------|
| **The Red Thread (cursor trail)** | Vanilla JS + SVG | Queue of 20 mouse points, cubic bezier path, stroke-dashoffset animation on dual SVG paths (glow + core) | 🔒 High |
| **The Time Loop (3D cube)** | GSAP timeline + CSS 3D | 4-face CSS cube with preserve-3d. GSAP timeline rotates cube 90° increments every 4s, swaps text content on faces out of view | 🔒 High |
| **Spatial Z-Gallery** | Three.js + R3F | Orthographic camera, 3 planes with custom shaders (vertex parallax, fragment cover-fit UVs + rounded corners). Scroll maps to camera.position.z. GSAP tweens scale/opacity on intersection | 🔒 High |
| **Cinematic Wipe Reveal** | GSAP ScrollTrigger | Two concurrent tweens: clip-path inset reveal (0% 100% → 0% 0%) + inner image scale (1.4 → 1.0). ScrollTrigger once:true at top 80% | Medium |
| **Rolling Digit Counter** | GSAP | Vertical strip translateY to `-targetValue * 10%`. Power4.out easing, 2s duration, staggered delays per digit | Medium |
| **Smooth Scroll** | Lenis | Lerp 0.1, synced to GSAP ticker via `lenis.raf()` in ScrollTrigger update loop | Low |
| **Navbar hide/show** | GSAP | Scroll direction detection (ScrollTrigger `onUpdate`). Tween translateY -80px on down, 0 on up | Low |
| **Product card hover** | CSS transitions | Sibling selector `group-hover` for dimming, scale transform on hovered card. No JS needed | Low |
| **Marquee** | CSS @keyframes | `translateX(0)` to `translateX(-50%)` on duplicated content. Linear, infinite | Low |

---

## State & Logic

### Cursor Trail — Point Queue Management
The trail must decouple visual smoothness from raw mouse events. Store mouse coordinates in a ring buffer of max 20 points. On each `requestAnimationFrame`, consume the oldest point if the array is full. The path `d` attribute is rebuilt from the queue every frame using cubic bezier interpolation. The `stroke-dashoffset` is set to `pathLen * 0.2` to create the tapered tail illusion. When the queue empties, stop the RAF loop (`isMoving = false`) and restart on next mousemove.

### Spatial Gallery — Scroll-to-Camera Mapping
Lenis scroll progress (0 to 1) maps linearly to `camera.position.z`. Each ImagePlane has a predefined Z position. Intersection is calculated by comparing `camera.z` to `plane.z + threshold`. On intersection: GSAP tweens `scale` to 1.2 and `uOpacity` uniform to 0. Mouse X/Y are normalized to [-1, 1] and passed to the vertex shader's `uParallax` uniform for horizontal drift.

### 3D Cube — Text Swap Timing
The cube rotates 90° every 4 seconds via GSAP. Text content on faces must swap only when a face is rotated 90° away from the viewer (invisible). Use GSAP `onComplete` callbacks on rotation tweens to trigger React state updates for the next phrase pair. This ensures no visible text flicker during the swap.

### Lenis ↔ GSAP Sync
Lenis must drive GSAP's ScrollTrigger, not the other way around. Initialize Lenis in a top-level hook. On every Lenis scroll event, call `ScrollTrigger.update()`. Use `gsap.ticker.add((time) => lenis.raf(time * 1000))` and disable GSAP's lag smoothing (`gsap.ticker.lagSmoothing(0)`) to prevent double-smoothing.

---

## Other Key Decisions

**Three.js via R3F, not vanilla**: The Spatial Gallery uses React Three Fiber for declarative scene management. This keeps gallery logic co-located with React state (scroll progress, mouse position) and avoids manual canvas lifecycle management.

**No SplitText**: The design's text animations (cube faces, counter) don't require character-level splitting. The `splitting` package is listed in design.md but not needed for the actual implementation. GSAP handles the 3D cube and digit strips without it.

**ImagesLoaded gating**: The Spatial Gallery `<Canvas>` renders only after `imagesloaded` resolves on the gallery container. This prevents texture aspect ratio miscalculations that would distort the cover-fit UV mapping in the fragment shader.

**Orthographic camera for gallery**: A perspective camera would introduce unwanted depth distortion on the editorial images. Orthographic projection maintains flat, magazine-like framing while still allowing Z-axis camera movement for the scroll transition effect.
