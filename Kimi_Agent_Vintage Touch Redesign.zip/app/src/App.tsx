import { useLenis } from './hooks/useLenis';
import CustomCursor from './sections/CustomCursor';
import Navbar from './sections/Navbar';
import Hero from './sections/Hero';
import Marquee from './sections/Marquee';
import NostalgiaTour from './sections/NostalgiaTour';
import SpatialGallery from './sections/SpatialGallery';
import ProductGrid from './sections/ProductGrid';
import HeritageCounter from './sections/HeritageCounter';
import Newsletter from './sections/Newsletter';
import Footer from './sections/Footer';

function App() {
  useLenis();

  return (
    <div className="relative bg-vt-surface-dark min-h-screen">
      <CustomCursor />
      <Navbar />
      <main>
        <Hero />
        <Marquee />
        <NostalgiaTour />
        <SpatialGallery />
        <ProductGrid />
        <HeritageCounter />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
}

export default App;
