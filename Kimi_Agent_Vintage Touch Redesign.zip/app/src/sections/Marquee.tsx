import { Sparkles } from 'lucide-react';

export default function Marquee() {
  const content = (
    <>
      <span className="mx-8 flex items-center gap-3 whitespace-nowrap">
        <Sparkles className="w-4 h-4" />
        NOSTALGIA TOUR 2024
      </span>
      <span className="mx-8 flex items-center gap-3 whitespace-nowrap">
        <Sparkles className="w-4 h-4" />
        LIMITED EDITION DROP
      </span>
      <span className="mx-8 flex items-center gap-3 whitespace-nowrap">
        <Sparkles className="w-4 h-4" />
        ALGER — VINTAGE TOUCH
      </span>
      <span className="mx-8 flex items-center gap-3 whitespace-nowrap">
        <Sparkles className="w-4 h-4" />
        فينتاج توتش — من الجزائر للعالم
      </span>
    </>
  );

  return (
    <section className="w-full bg-vt-red py-5 overflow-hidden">
      <div className="marquee-track flex animate-marquee">
        {/* Duplicate content for seamless loop */}
        <div className="flex items-center text-vt-white text-[13px] font-body font-semibold tracking-[0.12em] uppercase shrink-0">
          {content}
        </div>
        <div className="flex items-center text-vt-white text-[13px] font-body font-semibold tracking-[0.12em] uppercase shrink-0">
          {content}
        </div>
        <div className="flex items-center text-vt-white text-[13px] font-body font-semibold tracking-[0.12em] uppercase shrink-0">
          {content}
        </div>
        <div className="flex items-center text-vt-white text-[13px] font-body font-semibold tracking-[0.12em] uppercase shrink-0">
          {content}
        </div>
      </div>
    </section>
  );
}
