import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';

const phrases = [
  { ar: 'الجديد حبو و القديم ما تفرط فيه', en: 'LOVE THE NEW, NEVER ABANDON THE OLD' },
  { ar: 'فينتاج توتش — تراث يلبس', en: 'VINTAGE TOUCH — WEARABLE HERITAGE' },
  { ar: 'الأصالة في كل خيط', en: 'AUTHENTICITY IN EVERY THREAD' },
  { ar: 'من الجزائر للعالم', en: 'FROM ALGERIA TO THE WORLD' },
];

export default function Hero() {
  const cubeRef = useRef<HTMLDivElement>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    // Entrance animation
    const tl = gsap.timeline({ delay: 0.5 });
    tl.fromTo(
      '.hero-cube-container',
      { opacity: 0, scale: 0.8 },
      { opacity: 1, scale: 1, duration: 1.2, ease: 'power3.out' }
    );
    tl.fromTo(
      '.hero-subtitle',
      { opacity: 0, y: 30 },
      { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out' },
      '-=0.5'
    );
    tl.fromTo(
      '.hero-cta',
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.6, ease: 'power2.out' },
      '-=0.3'
    );

    // Auto-rotate every 4 seconds
    intervalRef.current = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % phrases.length);
    }, 4000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  useEffect(() => {
    if (cubeRef.current) {
      gsap.to(cubeRef.current, {
        rotateY: currentIndex * 90,
        duration: 1,
        ease: 'cubic-bezier(0.76, 0, 0.24, 1)',
      });
    }
  }, [currentIndex]);

  const currentPhrase = phrases[currentIndex];

  return (
    <section
      className="relative w-full h-screen flex items-center justify-center bg-vt-black overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Ambient background glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[600px] h-[600px] rounded-full bg-vt-red/5 blur-[120px]" />
      </div>

      {/* 3D Cube */}
      <div
        className="hero-cube-container relative"
        style={{ perspective: '1200px' }}
      >
        <div
          ref={cubeRef}
          className="relative preserve-3d"
          style={{
            width: '100%',
            maxWidth: '900px',
            height: '200px',
            transformStyle: 'preserve-3d',
            transition: 'transform 1s cubic-bezier(0.76, 0, 0.24, 1)',
            transform: `rotateY(${currentIndex * 90}deg)`,
          }}
        >
          {/* Front Face */}
          <div
            className="absolute inset-0 flex flex-col items-center justify-center backface-hidden overflow-hidden"
            style={{ transform: 'translateZ(100px)' }}
          >
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl text-vt-white text-center leading-[1.1] tracking-[-0.02em]">
              {currentPhrase.ar}
            </h1>
            <p className="mt-4 text-[10px] md:text-xs font-body font-medium tracking-[0.2em] text-vt-white/50 uppercase">
              {currentPhrase.en}
            </p>
          </div>

          {/* Right Face */}
          <div
            className="absolute inset-0 flex flex-col items-center justify-center backface-hidden overflow-hidden"
            style={{ transform: 'rotateY(90deg) translateZ(100px)' }}
          >
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl text-vt-white text-center leading-[1.1] tracking-[-0.02em]">
              {phrases[(currentIndex + 1) % phrases.length].ar}
            </h1>
            <p className="mt-4 text-[10px] md:text-xs font-body font-medium tracking-[0.2em] text-vt-white/50 uppercase">
              {phrases[(currentIndex + 1) % phrases.length].en}
            </p>
          </div>

          {/* Back Face */}
          <div
            className="absolute inset-0 flex flex-col items-center justify-center backface-hidden overflow-hidden"
            style={{ transform: 'rotateY(180deg) translateZ(100px)' }}
          >
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl text-vt-white text-center leading-[1.1] tracking-[-0.02em]">
              {phrases[(currentIndex + 2) % phrases.length].ar}
            </h1>
            <p className="mt-4 text-[10px] md:text-xs font-body font-medium tracking-[0.2em] text-vt-white/50 uppercase">
              {phrases[(currentIndex + 2) % phrases.length].en}
            </p>
          </div>

          {/* Left Face */}
          <div
            className="absolute inset-0 flex flex-col items-center justify-center backface-hidden overflow-hidden"
            style={{ transform: 'rotateY(-90deg) translateZ(100px)' }}
          >
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl text-vt-white text-center leading-[1.1] tracking-[-0.02em]">
              {phrases[(currentIndex + 3) % phrases.length].ar}
            </h1>
            <p className="mt-4 text-[10px] md:text-xs font-body font-medium tracking-[0.2em] text-vt-white/50 uppercase">
              {phrases[(currentIndex + 3) % phrases.length].en}
            </p>
          </div>
        </div>
      </div>

      {/* Subtitle */}
      <div className="hero-subtitle absolute bottom-32 left-0 right-0 text-center opacity-0">
        <p className="text-sm font-body text-vt-white/40 tracking-[0.15em] uppercase">
          Algerian Streetwear Since 2017
        </p>
      </div>

      {/* CTA Button */}
      <div className="hero-cta absolute bottom-16 left-0 right-0 flex justify-center opacity-0">
        <a
          href="#products"
          className="group relative px-8 py-3 border border-vt-white/30 text-vt-white text-xs font-body font-medium tracking-[0.15em] uppercase overflow-hidden transition-all duration-500 hover:border-vt-red"
        >
          <span className="relative z-10 group-hover:text-vt-white transition-colors duration-500">
            Shop Now
          </span>
          <span className="absolute inset-0 bg-vt-red transform -translate-x-full group-hover:translate-x-0 transition-transform duration-500 ease-out" />
        </a>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <div className="w-px h-8 bg-vt-white/20 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-4 bg-vt-red animate-bounce" />
        </div>
      </div>

      {/* Model images peeking from edges */}
      <div
        className="absolute left-0 bottom-0 w-[200px] md:w-[300px] h-[300px] md:h-[450px] opacity-40 pointer-events-none transition-transform duration-700"
        style={{ transform: isHovered ? 'translateX(10px)' : 'translateX(0)' }}
      >
        <img
          src="/images/hero-model-1.jpg"
          alt=""
          className="w-full h-full object-cover object-top"
          style={{ maskImage: 'linear-gradient(to right, black 30%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to right, black 30%, transparent 100%)' }}
        />
      </div>
      <div
        className="absolute right-0 bottom-0 w-[200px] md:w-[300px] h-[300px] md:h-[450px] opacity-40 pointer-events-none transition-transform duration-700"
        style={{ transform: isHovered ? 'translateX(-10px)' : 'translateX(0)' }}
      >
        <img
          src="/images/hero-model-3.jpg"
          alt=""
          className="w-full h-full object-cover object-top"
          style={{ maskImage: 'linear-gradient(to left, black 30%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to left, black 30%, transparent 100%)' }}
        />
      </div>
    </section>
  );
}
