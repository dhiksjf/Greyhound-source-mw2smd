import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const galleryItems = [
  {
    image: '/images/gallery-1.jpg',
    title: 'Jorts Collection',
    subtitle: 'فيintاج دينم',
  },
  {
    image: '/images/gallery-2.jpg',
    title: 'Sneakers Drop',
    subtitle: 'حذاء كلاسيكي',
  },
  {
    image: '/images/gallery-3.jpg',
    title: 'Graphic Tees',
    subtitle: 'تيشيرتات مطبوعة',
  },
];

export default function SpatialGallery() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Horizontal scroll effect
      const container = containerRef.current;
      if (!container) return;

      const scrollTween = gsap.to(container, {
        x: () => -(container.scrollWidth - window.innerWidth),
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: () => `+=${container.scrollWidth - window.innerWidth}`,
          scrub: 1,
          pin: true,
          anticipatePin: 1,
          invalidateOnRefresh: true,
        },
      });

      // Individual item animations
      itemRefs.current.forEach((item) => {
        if (!item) return;

        const img = item.querySelector('img');
        const text = item.querySelector('.gallery-text');

        // Parallax on the images
        gsap.fromTo(
          img,
          { scale: 1.3, x: -50 },
          {
            scale: 1,
            x: 50,
            ease: 'none',
            scrollTrigger: {
              trigger: item,
              containerAnimation: scrollTween,
              start: 'left right',
              end: 'right left',
              scrub: true,
            },
          }
        );

        // Text reveal
        if (text) {
          gsap.fromTo(
            text,
            { opacity: 0, y: 30 },
            {
              opacity: 1,
              y: 0,
              duration: 0.6,
              ease: 'power2.out',
              scrollTrigger: {
                trigger: item,
                containerAnimation: scrollTween,
                start: 'left 70%',
                toggleActions: 'play none none reverse',
              },
            }
          );
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="gallery"
      className="relative w-full h-screen bg-vt-black overflow-hidden"
    >
      {/* Section label */}
      <div className="absolute top-10 left-6 md:left-10 z-10">
        <span className="text-[11px] font-body font-medium tracking-[0.2em] text-vt-red uppercase">
          The Gallery
        </span>
        <h2 className="mt-2 font-display text-3xl md:text-4xl text-vt-white">
          Collection Corridor
        </h2>
      </div>

      {/* Scroll progress indicator */}
      <div className="absolute bottom-10 left-6 md:left-10 z-10 flex items-center gap-4">
        <span className="text-[10px] font-body tracking-[0.15em] text-vt-white/40 uppercase">
          Scroll to explore
        </span>
        <div className="w-16 h-px bg-vt-white/20 relative overflow-hidden">
          <div className="absolute top-0 left-0 h-full bg-vt-red gallery-progress" style={{ width: '0%' }} />
        </div>
      </div>

      {/* Horizontal scroll container */}
      <div
        ref={containerRef}
        className="flex items-center h-full gap-8 md:gap-16 pl-6 md:pl-10 pr-[50vw]"
        style={{ width: 'max-content' }}
      >
        {galleryItems.map((item, i) => (
          <div
            key={i}
            ref={(el) => { itemRefs.current[i] = el; }}
            className="relative flex-shrink-0 w-[70vw] md:w-[45vw] lg:w-[35vw] h-[60vh] md:h-[70vh] group"
          >
            <div className="relative w-full h-full overflow-hidden">
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              {/* Overlay */}
              <div className="absolute inset-0 bg-vt-black/30 group-hover:bg-vt-black/10 transition-colors duration-500" />

              {/* Corner accents */}
              <div className="absolute top-4 left-4 w-8 h-8 border-l-2 border-t-2 border-vt-red opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute bottom-4 right-4 w-8 h-8 border-r-2 border-b-2 border-vt-red opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </div>

            {/* Text overlay */}
            <div className="gallery-text absolute bottom-6 left-6 right-6">
              <span className="text-[10px] font-body tracking-[0.2em] text-vt-red uppercase">
                {item.subtitle}
              </span>
              <h3 className="mt-1 font-display text-2xl md:text-3xl text-vt-white">
                {item.title}
              </h3>
            </div>
          </div>
        ))}

        {/* End spacer with CTA */}
        <div className="flex-shrink-0 w-[30vw] h-[60vh] md:h-[70vh] flex items-center justify-center">
          <a
            href="#products"
            className="group flex flex-col items-center gap-4 text-center"
          >
            <div className="w-16 h-16 rounded-full border border-vt-white/30 flex items-center justify-center group-hover:bg-vt-red group-hover:border-vt-red transition-all duration-500">
              <span className="text-vt-white text-xl group-hover:scale-110 transition-transform duration-300">
                →
              </span>
            </div>
            <span className="text-[11px] font-body tracking-[0.15em] text-vt-white/60 uppercase group-hover:text-vt-red transition-colors duration-300">
              View All
            </span>
          </a>
        </div>
      </div>
    </section>
  );
}
