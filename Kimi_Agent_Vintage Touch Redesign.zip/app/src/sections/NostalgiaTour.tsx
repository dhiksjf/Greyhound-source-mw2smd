import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function NostalgiaTour() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imageContainerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Cinematic wipe reveal for image
      if (imageContainerRef.current && imageRef.current) {
        gsap.timeline({
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        })
          .fromTo(
            imageContainerRef.current,
            { clipPath: 'inset(0% 100% 0% 0%)' },
            { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.2, ease: 'power3.inOut' }
          )
          .fromTo(
            imageRef.current,
            { scale: 1.4 },
            { scale: 1, duration: 1.5, ease: 'power2.out' },
            0
          );
      }

      // Text fade in
      if (textRef.current) {
        gsap.fromTo(
          textRef.current.children,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.15,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: textRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="nostalgia"
      className="relative w-full py-32 md:py-48 bg-vt-surface-dark overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-16 items-center">
          {/* Left Column - Text (40%) */}
          <div ref={textRef} className="md:col-span-5 space-y-8">
            <div>
              <span className="text-[11px] font-body font-medium tracking-[0.2em] text-vt-red uppercase">
                The Collection
              </span>
              <h2 className="mt-4 font-display text-4xl md:text-5xl lg:text-6xl text-vt-white leading-[1.05] tracking-[-0.02em]">
                Nostalgia<br />Tour
              </h2>
            </div>

            <p className="text-[15px] font-body text-vt-white/60 leading-[1.7] max-w-md">
              مع فينتاج توتش و الـHYPE، تمتعوا مع أفضل إصدارات الستريت ويير.
              Where vintage culture meets Algerian streetwear identity. Every piece
              tells a story of heritage reimagined for the modern era.
            </p>

            <p className="text-[15px] font-body text-vt-white/60 leading-[1.7] max-w-md">
              The Nostalgia Tour collection brings together Japanese-inspired
              embroidery, premium denim washes, and bold graphic treatments that
              honor the past while pushing forward.
            </p>

            <a
              href="#products"
              className="group inline-flex items-center gap-3 text-xs font-body font-medium tracking-[0.15em] text-vt-white uppercase hover:text-vt-red transition-colors duration-300"
            >
              <span>Explore Collection</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
            </a>
          </div>

          {/* Right Column - Image (60%) */}
          <div className="md:col-span-7">
            <div
              ref={imageContainerRef}
              className="relative aspect-[3/4] md:aspect-[4/5] overflow-hidden"
              style={{ clipPath: 'inset(0% 100% 0% 0%)' }}
            >
              <img
                ref={imageRef}
                src="/images/nostalgia-editorial.jpg"
                alt="VT Nostalgia Tour - Model wearing Konoha Baggy Pants"
                className="w-full h-full object-cover"
                style={{ transform: 'scale(1.4)' }}
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-vt-surface-dark/60 via-transparent to-transparent" />
            </div>
          </div>
        </div>
      </div>

      {/* Decorative line */}
      <div className="absolute top-1/2 left-0 w-full h-px bg-vt-border-dark/30 -translate-y-1/2 pointer-events-none" />
    </section>
  );
}
