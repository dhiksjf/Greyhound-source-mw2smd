import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ShoppingBag } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const products = [
  {
    id: 1,
    name: 'PACK JORTS+T-SHIRT',
    nameAr: 'باك جورتس + تيشيرت',
    price: '5,900.00',
    originalPrice: null,
    image: '/images/product-baggy.jpg',
    sale: false,
  },
  {
    id: 2,
    name: 'VT (فينتاج توتش) JORTS',
    nameAr: 'جين قصير فينتاج',
    price: '5,400.00',
    originalPrice: '6,900.00',
    image: '/images/product-jorts.jpg',
    sale: true,
  },
  {
    id: 3,
    name: 'VT X OKAIRI (KONOHA) JORTS',
    nameAr: 'جورتس كونوها',
    price: '5,400.00',
    originalPrice: '6,900.00',
    image: '/images/product-konoha.jpg',
    sale: true,
  },
  {
    id: 4,
    name: 'VT X OKAIRI (SAHRA) JORTS',
    nameAr: 'جورتس الصحراء',
    price: '5,400.00',
    originalPrice: '6,900.00',
    image: '/images/product-jorts.jpg',
    sale: true,
  },
  {
    id: 5,
    name: 'VT (فينتاج توتش) BAGGY PANTS',
    nameAr: 'بنطلون باغي',
    price: '5,900.00',
    originalPrice: '7,900.00',
    image: '/images/product-konoha.jpg',
    sale: true,
  },
  {
    id: 6,
    name: 'VT X OKAIRI (KONOHA) BAGGY PANTS',
    nameAr: 'بنطلون كونوها',
    price: '5,900.00',
    originalPrice: '7,900.00',
    image: '/images/product-baggy.jpg',
    sale: true,
  },
];

export default function ProductGrid() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Section header animation
      gsap.fromTo(
        '.product-header',
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Grid items stagger animation
      const cards = gridRef.current?.querySelectorAll('.product-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { opacity: 0, y: 60 },
          {
            opacity: 1,
            y: 0,
            duration: 0.7,
            stagger: 0.1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: gridRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="products"
      className="relative w-full py-32 md:py-48 bg-vt-surface-dark"
    >
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Header */}
        <div className="product-header flex flex-col md:flex-row md:items-end md:justify-between mb-16 md:mb-20">
          <div>
            <span className="text-[11px] font-body font-medium tracking-[0.2em] text-vt-red uppercase">
              Shop Now
            </span>
            <h2 className="mt-3 font-display text-4xl md:text-5xl lg:text-6xl text-vt-white leading-[1.05]">
              Featured<br />Collection
            </h2>
          </div>
          <p className="mt-6 md:mt-0 text-sm font-body text-vt-white/50 max-w-xs text-right">
            اخرب طلة و شوف شاع الاصدارات لي عندنا
          </p>
        </div>

        {/* Product Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
        >
          {products.map((product) => (
            <div
              key={product.id}
              className="product-card group relative"
              onMouseEnter={() => setHoveredId(product.id)}
              onMouseLeave={() => setHoveredId(null)}
              style={{
                opacity: hoveredId === null || hoveredId === product.id ? 1 : 0.4,
                transform: hoveredId === product.id ? 'scale(1.02)' : 'scale(1)',
              }}
            >
              {/* Image Container */}
              <div className="relative aspect-[3/4] overflow-hidden bg-vt-void-grey">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />

                {/* Sale badge */}
                {product.sale && (
                  <div className="absolute top-4 left-4 bg-vt-red text-vt-white text-[10px] font-body font-bold tracking-[0.1em] uppercase px-3 py-1.5">
                    SALE
                  </div>
                )}

                {/* Hover overlay with button */}
                <div className="absolute inset-0 bg-vt-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-400 flex items-center justify-center">
                  <button className="flex items-center gap-2 px-6 py-3 bg-vt-red text-vt-white text-[11px] font-body font-medium tracking-[0.12em] uppercase hover:bg-vt-red-hover transition-colors duration-300 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-400">
                    <ShoppingBag className="w-4 h-4" />
                    Select Options
                  </button>
                </div>
              </div>

              {/* Product Info */}
              <div className="mt-5 space-y-2">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-sm font-body font-medium text-vt-white tracking-wide">
                      {product.name}
                    </h3>
                    <p className="text-[11px] font-body text-vt-white/40 mt-0.5">
                      {product.nameAr}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-sm font-body font-semibold text-vt-white">
                    {product.price} <span className="text-[10px] font-normal">DA</span>
                  </span>
                  {product.originalPrice && (
                    <span className="text-xs font-body text-vt-white/30 line-through">
                      {product.originalPrice} DA
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="mt-16 flex justify-center">
          <a
            href="#"
            className="group relative px-10 py-4 border border-vt-white/20 text-vt-white text-xs font-body font-medium tracking-[0.15em] uppercase overflow-hidden transition-all duration-500 hover:border-vt-red"
          >
            <span className="relative z-10 group-hover:text-vt-white transition-colors duration-500">
              View All Products
            </span>
            <span className="absolute inset-0 bg-vt-red transform -translate-x-full group-hover:translate-x-0 transition-transform duration-500 ease-out" />
          </a>
        </div>
      </div>
    </section>
  );
}
