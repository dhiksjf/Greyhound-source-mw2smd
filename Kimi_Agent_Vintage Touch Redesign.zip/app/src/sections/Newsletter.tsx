import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, Send } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function Newsletter() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.newsletter-content > *',
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.7,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 3000);
      setEmail('');
    }
  };

  return (
    <section
      ref={sectionRef}
      className="relative w-full py-32 md:py-40 bg-vt-surface-dark overflow-hidden"
    >
      {/* Decorative stamp illustration */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] opacity-5 pointer-events-none">
        <svg viewBox="0 0 200 200" className="w-full h-full">
          <rect x="20" y="20" width="160" height="160" rx="10" fill="none" stroke="#e30614" strokeWidth="2" strokeDasharray="8 4" />
          <rect x="35" y="35" width="130" height="130" rx="5" fill="none" stroke="#e30614" strokeWidth="1" />
          <circle cx="100" cy="100" r="40" fill="none" stroke="#e30614" strokeWidth="1.5" />
          <path d="M70 100 L130 100 M100 70 L100 130" stroke="#e30614" strokeWidth="1" />
          <circle cx="100" cy="100" r="15" fill="#e30614" opacity="0.3" />
        </svg>
      </div>

      <div className="newsletter-content relative max-w-2xl mx-auto px-6 md:px-10 text-center">
        <div className="flex justify-center mb-6">
          <div className="w-14 h-14 rounded-full border border-vt-red/30 flex items-center justify-center">
            <Mail className="w-6 h-6 text-vt-red" />
          </div>
        </div>

        <h2 className="font-display text-4xl md:text-5xl text-vt-white mb-3">
          كاش جديد؟
        </h2>
        <p className="text-sm font-body text-vt-white/50 mb-2">
          اشترك للاطلاع على اخبارنا و اخر العروض الحصرية
        </p>
        <p className="text-xs font-body text-vt-white/30 mb-10 tracking-wide">
          Subscribe for exclusive drops and early access
        </p>

        {submitted ? (
          <div className="flex items-center justify-center gap-2 text-vt-red">
            <Send className="w-4 h-4" />
            <span className="text-sm font-body">Thank you for subscribing!</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your Email Address"
              required
              className="flex-1 px-5 py-3.5 bg-transparent border border-vt-border-dark text-vt-white text-sm font-body placeholder:text-vt-white/30 focus:outline-none focus:border-vt-red transition-colors duration-300"
            />
            <button
              type="submit"
              className="px-8 py-3.5 bg-vt-red text-vt-white text-xs font-body font-semibold tracking-[0.12em] uppercase hover:bg-vt-red-hover transition-colors duration-300 flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              Subscribe
            </button>
          </form>
        )}
      </div>
    </section>
  );
}
