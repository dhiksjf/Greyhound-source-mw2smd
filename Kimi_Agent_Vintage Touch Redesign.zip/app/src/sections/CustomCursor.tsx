import { useEffect, useRef, useCallback } from 'react';

interface Point {
  x: number;
  y: number;
}

export default function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const trailContainerRef = useRef<HTMLDivElement>(null);
  const glowPathRef = useRef<SVGPathElement>(null);
  const corePathRef = useRef<SVGPathElement>(null);
  const pointsRef = useRef<Point[]>([]);
  const mouseRef = useRef<Point>({ x: 0, y: 0 });
  const isMovingRef = useRef(false);
  const rafRef = useRef<number>(0);
  const isHoveringRef = useRef(false);

  const MAX_POINTS = 20;

  const getSmoothPath = useCallback((points: Point[]): string => {
    if (points.length < 2) return '';
    let d = `M ${points[0].x} ${points[0].y}`;
    for (let i = 1; i < points.length; i++) {
      const p0 = points[i - 1];
      const p1 = points[i];
      const midX = (p0.x + p1.x) / 2;
      d += ` Q ${p0.x} ${p0.y} ${midX} ${p1.y}`;
    }
    return d;
  }, []);

  const animate = useCallback(() => {
    rafRef.current = requestAnimationFrame(animate);

    const points = pointsRef.current;
    const glowPath = glowPathRef.current;
    const corePath = corePathRef.current;

    if (!glowPath || !corePath || points.length < 2) return;

    const d = getSmoothPath(points);
    glowPath.setAttribute('d', d);
    corePath.setAttribute('d', d);

    try {
      const pathLen = corePath.getTotalLength();
      const dashArray = `${pathLen} ${pathLen}`;
      const dashOffset = pathLen * 0.2;

      corePath.style.strokeDasharray = dashArray;
      corePath.style.strokeDashoffset = `${dashOffset}`;
      glowPath.style.strokeDasharray = dashArray;
      glowPath.style.strokeDashoffset = `${dashOffset}`;

      corePath.style.opacity = '1';
      glowPath.style.opacity = '1';
    } catch {
      // Path might be too short
    }

    if (points.length > 0) {
      pointsRef.current = points.slice(1);
    } else {
      isMovingRef.current = false;
    }
  }, [getSmoothPath]);

  useEffect(() => {
    // Check for touch device
    const isTouchDevice = window.matchMedia('(pointer: coarse)').matches;
    if (isTouchDevice) return;

    // Add custom cursor class to body
    document.body.classList.add('custom-cursor-active');

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = { x: e.clientX, y: e.clientY };

      // Update dot position immediately
      if (dotRef.current) {
        dotRef.current.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
      }

      // Add point for trail
      pointsRef.current.push({ x: e.clientX, y: e.clientY });
      if (pointsRef.current.length > MAX_POINTS) {
        pointsRef.current.shift();
      }

      if (!isMovingRef.current) {
        isMovingRef.current = true;
        animate();
      }
    };

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const isInteractive = target.closest('a, button, [role="button"], input, textarea, select');
      isHoveringRef.current = !!isInteractive;

      if (dotRef.current) {
        if (isInteractive) {
          dotRef.current.style.width = '40px';
          dotRef.current.style.height = '40px';
          dotRef.current.style.backgroundColor = 'transparent';
          dotRef.current.style.border = '2px solid #e30614';
          dotRef.current.style.mixBlendMode = 'difference';
        } else {
          dotRef.current.style.width = '10px';
          dotRef.current.style.height = '10px';
          dotRef.current.style.backgroundColor = '#e30614';
          dotRef.current.style.border = 'none';
          dotRef.current.style.mixBlendMode = 'normal';
        }
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseover', handleMouseOver);

    return () => {
      document.body.classList.remove('custom-cursor-active');
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseover', handleMouseOver);
      cancelAnimationFrame(rafRef.current);
    };
  }, [animate]);

  // Don't render on touch devices
  if (typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches) {
    return null;
  }

  return (
    <>
      {/* SVG Trail */}
      <div
        ref={trailContainerRef}
        className="fixed inset-0 pointer-events-none z-[9998]"
      >
        <svg className="w-full h-full">
          <defs>
            <filter id="cursor-glow">
              <feGaussianBlur stdDeviation="4" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="coloredBlur" />
              </feMerge>
            </filter>
          </defs>
          <path
            ref={glowPathRef}
            fill="none"
            stroke="#e30614"
            strokeWidth="8"
            strokeLinecap="round"
            filter="url(#cursor-glow)"
            opacity="0"
          />
          <path
            ref={corePathRef}
            fill="none"
            stroke="#ffffff"
            strokeWidth="2"
            strokeLinecap="round"
            opacity="0"
          />
        </svg>
      </div>

      {/* Cursor Dot */}
      <div
        ref={dotRef}
        className="fixed top-0 left-0 z-[9999] pointer-events-none"
        style={{
          width: '10px',
          height: '10px',
          borderRadius: '50%',
          backgroundColor: '#e30614',
          transform: 'translate(-50%, -50%)',
          marginLeft: '-5px',
          marginTop: '-5px',
          transition: 'width 0.3s, height 0.3s, background-color 0.3s, border 0.3s',
        }}
      />
    </>
  );
}
