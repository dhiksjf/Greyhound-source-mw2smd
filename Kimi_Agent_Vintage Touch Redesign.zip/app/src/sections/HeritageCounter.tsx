import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface RollingDigitProps {
  targetValue: number;
  delay?: number;
  isActive: boolean;
}

function RollingDigit({ targetValue, delay = 0, isActive }: RollingDigitProps) {
  const stripRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (!isActive || !stripRef.current) return;

    const tl = gsap.timeline({ delay });
    tl.to(stripRef.current, {
      y: `${-targetValue * 10}%`,
      duration: 2,
      ease: 'power4.out',
    });

    return () => {
      tl.kill();
    };
  }, [isActive, targetValue, delay]);

  return (
    <span className="inline-block overflow-hidden h-[1.2em] leading-[1.2em] align-bottom relative">
      <span
        ref={stripRef}
        className="flex flex-col h-max absolute bottom-0 left-0"
        style={{ transform: 'translateY(0%)' }}
      >
        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
          <span key={num} className="block h-[1.2em]">
            {num}
          </span>
        ))}
      </span>
    </span>
  );
}

const counters = [
  {
    label: 'Since',
    labelAr: 'منذ',
    value: [2, 0, 1, 7],
    suffix: '',
  },
  {
    label: 'Cities',
    labelAr: 'مدن',
    value: [0, 2],
    suffix: '',
  },
  {
    label: 'Collection Pieces',
    labelAr: 'قطعة',
    value: [2, 4],
    suffix: '+',
  },
];

export default function HeritageCounter() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top 70%',
        onEnter: () => setIsActive(true),
        onLeaveBack: () => setIsActive(false),
      });

      // Label animations
      gsap.fromTo(
        '.counter-label',
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="counter"
      className="relative w-full py-32 md:py-48 bg-vt-black overflow-hidden"
    >
      {/* Background texture */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Header */}
        <div className="text-center mb-20 md:mb-28">
          <span className="text-[11px] font-body font-medium tracking-[0.2em] text-vt-red uppercase">
            Our Heritage
          </span>
          <h2 className="mt-4 font-display text-4xl md:text-5xl lg:text-6xl text-vt-white">
            By The Numbers
          </h2>
        </div>

        {/* Counters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 md:gap-8">
          {counters.map((counter, i) => (
            <div key={i} className="counter-label text-center">
              {/* Number Display */}
              <div className="font-display text-7xl md:text-8xl lg:text-9xl text-vt-white leading-none tracking-[-0.03em]">
                {counter.value.map((digit, j) => (
                  <RollingDigit
                    key={j}
                    targetValue={digit}
                    delay={i * 0.2 + j * 0.1}
                    isActive={isActive}
                  />
                ))}
                {counter.suffix && (
                  <span className="text-vt-red">{counter.suffix}</span>
                )}
              </div>

              {/* Labels */}
              <div className="mt-6 space-y-1">
                <p className="text-[11px] font-body tracking-[0.2em] text-vt-white/50 uppercase">
                  {counter.label}
                </p>
                <p className="text-xs font-body text-vt-white/30">
                  {counter.labelAr}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-1/2 left-8 w-px h-32 bg-vt-border-dark/50 -translate-y-1/2 hidden lg:block" />
      <div className="absolute top-1/2 right-8 w-px h-32 bg-vt-border-dark/50 -translate-y-1/2 hidden lg:block" />
    </section>
  );
}
