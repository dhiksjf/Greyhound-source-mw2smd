import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, Phone, ArrowUpRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function Footer() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.footer-col',
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.7,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const accountLinks = [
    { label: 'FAQ', href: '#' },
    { label: 'Shipping & Return', href: '#' },
    { label: 'Contact Us', href: '#' },
  ];

  const aboutLinks = [
    { label: 'Who are we?', href: '#' },
    { label: 'Privacy Policy', href: '#' },
    { label: 'Terms of Service', href: '#' },
  ];

  return (
    <footer
      ref={sectionRef}
      id="footer"
      className="relative w-full bg-vt-surface-light text-vt-black"
    >
      {/* Large CTA Section */}
      <div className="py-24 md:py-32 px-6 md:px-10 border-b border-vt-border-light">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="font-display text-3xl md:text-5xl lg:text-6xl text-vt-black leading-[1.1] mb-8">
            اخرب طلة و شوف شاع<br className="hidden md:block" /> الاصدارات لي عندنا
          </h2>
          <p className="text-sm font-body text-vt-black/50 mb-10 max-w-md mx-auto">
            Explore the latest hype. Limited drops, exclusive collaborations, and timeless pieces.
          </p>
          <a
            href="#products"
            className="group inline-flex items-center gap-3 px-10 py-4 bg-vt-black text-vt-white text-xs font-body font-medium tracking-[0.15em] uppercase hover:bg-vt-red transition-colors duration-500"
          >
            <span>View Products</span>
            <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-300" />
          </a>
        </div>
      </div>

      {/* Footer Grid */}
      <div className="py-16 md:py-20 px-6 md:px-10">
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {/* Logo & Tagline */}
          <div className="footer-col">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-vt-red flex items-center justify-center">
                <span className="text-vt-white font-display font-bold text-sm">V</span>
              </div>
              <div>
                <span className="block text-sm font-display font-bold tracking-tight">VINTAGE TOUCH</span>
                <span className="block text-[9px] font-body tracking-[0.15em] text-vt-black/40 uppercase">Alger 2017</span>
              </div>
            </div>
            <p className="text-xs font-body text-vt-black/50 leading-relaxed max-w-[200px]">
              Algerian streetwear since 2017. Connecting heritage with contemporary fashion.
            </p>
          </div>

          {/* Account Links */}
          <div className="footer-col">
            <h4 className="text-[11px] font-body font-semibold tracking-[0.15em] text-vt-black uppercase mb-5">
              Account
            </h4>
            <ul className="space-y-3">
              {accountLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm font-body text-vt-black/60 hover:text-vt-red transition-colors duration-300 flex items-center gap-1 group"
                  >
                    {link.label}
                    <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* About Links */}
          <div className="footer-col">
            <h4 className="text-[11px] font-body font-semibold tracking-[0.15em] text-vt-black uppercase mb-5">
              About Us
            </h4>
            <ul className="space-y-3">
              {aboutLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-sm font-body text-vt-black/60 hover:text-vt-red transition-colors duration-300 flex items-center gap-1 group"
                  >
                    {link.label}
                    <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div className="footer-col">
            <h4 className="text-[11px] font-body font-semibold tracking-[0.15em] text-vt-black uppercase mb-5">
              Contact
            </h4>
            <div className="space-y-4">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-vt-red mt-0.5 shrink-0" />
                <div>
                  <p className="text-xs font-body text-vt-black/60 leading-relaxed">
                    Alger: باب الزوار- حي 2068 مسكن- عمارة A32 ( مقابل جامعة UTHB- الباب الثاني - الوسط)
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-vt-red shrink-0" />
                <p className="text-xs font-body text-vt-black/60">
                  +213 7 70536351
                </p>
              </div>
              <div className="pt-2 border-t border-vt-border-light">
                <p className="text-xs font-body text-vt-black/60 leading-relaxed">
                  Boumerdes: Cité 11 Décembre 1960 (Coopératives, en face du grand rond-point)
                </p>
                <p className="text-xs font-body text-vt-black/60 mt-1">
                  0542097472
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="py-6 px-6 md:px-10 border-t border-vt-border-light">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[10px] font-body text-vt-black/40 tracking-wide">
            &copy; 2024 VINTAGE TOUCH. All rights reserved. Alger, Algeria.
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-[10px] font-body text-vt-black/40 hover:text-vt-red transition-colors duration-300 tracking-wide">
              Instagram
            </a>
            <a href="#" className="text-[10px] font-body text-vt-black/40 hover:text-vt-red transition-colors duration-300 tracking-wide">
              Facebook
            </a>
            <a href="#" className="text-[10px] font-body text-vt-black/40 hover:text-vt-red transition-colors duration-300 tracking-wide">
              TikTok
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
