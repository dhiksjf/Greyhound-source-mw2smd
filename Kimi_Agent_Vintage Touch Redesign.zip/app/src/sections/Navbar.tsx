import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ShoppingBag, Search, Menu, X } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function Navbar() {
  const navRef = useRef<HTMLElement>(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const lastScrollY = useRef(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentY = window.scrollY;
      setIsScrolled(currentY > 100);

      if (navRef.current) {
        if (currentY > lastScrollY.current && currentY > 100) {
          gsap.to(navRef.current, { y: -80, duration: 0.3, ease: 'power2.out' });
        } else {
          gsap.to(navRef.current, { y: 0, duration: 0.3, ease: 'power2.out' });
        }
      }
      lastScrollY.current = currentY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'HOME', href: '#' },
    { label: 'SHOP', href: '#products' },
    { label: 'NEW', href: '#gallery' },
    { label: 'SNEAKERS', href: '#', badge: 'NEW' },
    { label: 'NOSTALGIA TOUR', href: '#nostalgia', badge: 'NEW' },
    { label: 'ABOUT US', href: '#counter' },
    { label: 'CONTACT', href: '#footer' },
  ];

  return (
    <>
      <nav
        ref={navRef}
        className={`fixed top-0 left-0 right-0 z-50 h-20 flex items-center justify-between px-6 md:px-10 transition-all duration-500 ${
          isScrolled ? 'bg-vt-surface-dark/80 backdrop-blur-xl border-b border-vt-border-dark/50' : 'bg-transparent'
        }`}
      >
        {/* Left: Brand */}
        <div className="flex items-center gap-6">
          <span className="text-[11px] font-body font-medium tracking-[0.15em] text-vt-white/60 uppercase hidden md:block">
            VT EST. 2017
          </span>
        </div>

        {/* Center: Logo */}
        <a href="#" className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center">
          <div className="w-8 h-8 bg-vt-red flex items-center justify-center">
            <span className="text-vt-white font-display font-bold text-sm">V</span>
          </div>
        </a>

        {/* Right: Actions */}
        <div className="flex items-center gap-5">
          <button className="text-vt-white/80 hover:text-vt-red transition-colors duration-300">
            <Search className="w-5 h-5" />
          </button>
          <button className="text-vt-white/80 hover:text-vt-red transition-colors duration-300 relative">
            <ShoppingBag className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-vt-red rounded-full text-[9px] font-bold flex items-center justify-center">
              0
            </span>
          </button>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="text-vt-white/80 hover:text-vt-red transition-colors duration-300 md:hidden"
          >
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <span className="hidden md:block text-[11px] font-body font-medium tracking-[0.15em] text-vt-white/60 uppercase cursor-pointer hover:text-vt-red transition-colors duration-300">
            MENU
          </span>
        </div>
      </nav>

      {/* Desktop Nav Links - Below the main nav bar */}
      <div
        className={`fixed top-20 left-0 right-0 z-40 hidden md:flex items-center justify-center gap-8 py-4 transition-all duration-500 ${
          isScrolled ? 'bg-vt-surface-dark/80 backdrop-blur-xl border-b border-vt-border-dark/30' : 'bg-transparent'
        }`}
      >
        {navLinks.map((link) => (
          <a
            key={link.label}
            href={link.href}
            className="relative text-[11px] font-body font-medium tracking-[0.12em] text-vt-white/70 uppercase hover:text-vt-red transition-colors duration-300 group"
          >
            {link.label}
            {link.badge && (
              <span className="absolute -top-2 -right-6 bg-vt-red text-[8px] font-bold text-vt-white px-1 py-0.5 rounded-sm">
                {link.badge}
              </span>
            )}
            <span className="absolute bottom-0 left-0 w-0 h-px bg-vt-red group-hover:w-full transition-all duration-300" />
          </a>
        ))}
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-40 bg-vt-surface-dark/95 backdrop-blur-xl md:hidden pt-24 px-8">
          <div className="flex flex-col gap-6">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="text-2xl font-display text-vt-white/90 hover:text-vt-red transition-colors duration-300"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
