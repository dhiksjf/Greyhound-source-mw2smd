#pragma once
#include "wraith_types.h"
#include <fstream>
#include <cstdio>
#include <algorithm>
#include <unordered_set>

// ===========================================================================
//  SMD Writer — converts WraithModel/WraithAnim to .smd files
//  Follows Valve's GOLDSOURCE format: single bone per vertex, clamped UVs
// ===========================================================================
struct SMDWriter {

    // Write reference (model) SMD from a SmdScene
    static bool WriteRefSMD(const std::string& path, const SmdScene& scene) {
        std::ofstream f(path);
        if (!f) return false;
        
        f << "version 1\n";
        
        // Nodes
        f << "nodes\n";
        for (auto& b : scene.bones) {
            f << b.index << " \"" << b.name << "\" " << b.parent << "\n";
        }
        f << "end\n";
        
        // Skeleton (reference pose, time 0)
        f << "skeleton\n";
        f << "time 0\n";
        for (auto& b : scene.bones) {
            char buf[256];
            std::snprintf(buf, sizeof(buf), "%d %.6f %.6f %.6f %.6f %.6f %.6f\n",
                b.index, b.pos.x, b.pos.y, b.pos.z, b.rot.x, b.rot.y, b.rot.z);
            f << buf;
        }
        f << "end\n";
        
        // Triangles
        f << "triangles\n";
        for (auto& tri : scene.tris) {
            f << tri.tex << "\n";
            for (int i = 0; i < 3; i++) {
                auto& v = tri.v[i];
                // Clamp UVs to [0,1] for GoldSrc
                double u = std::clamp(v.uv.u, 0.0, 1.0);
                double v_ = std::clamp(v.uv.v, 0.0, 1.0);
                char buf[256];
                std::snprintf(buf, sizeof(buf),
                    "%d %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f\n",
                    v.bone,
                    v.pos.x, v.pos.y, v.pos.z,
                    v.nrm.x, v.nrm.y, v.nrm.z,
                    u, v_);
                f << buf;
            }
        }
        f << "end\n";
        
        return true;
    }

    // Write animation SMD from a SmdAnim
    static bool WriteAnimSMD(const std::string& path, const SmdScene& refScene, const SmdAnim& anim) {
        std::ofstream f(path);
        if (!f) return false;
        
        f << "version 1\n";
        
        // Nodes (must match reference SMD)
        f << "nodes\n";
        for (auto& b : refScene.bones) {
            f << b.index << " \"" << b.name << "\" " << b.parent << "\n";
        }
        f << "end\n";
        
        // Skeleton (per-frame)
        f << "skeleton\n";
        int nBones = (int)refScene.bones.size();
        for (int fi = 0; fi < anim.frames; fi++) {
            f << "time " << fi << "\n";
            for (int bi = 0; bi < nBones && bi < (int)anim.data[fi].size(); bi++) {
                auto& frame = anim.data[fi][bi];
                char buf[256];
                std::snprintf(buf, sizeof(buf),
                    "%d %.6f %.6f %.6f %.6f %.6f %.6f\n",
                    bi,
                    frame.pos.x, frame.pos.y, frame.pos.z,
                    frame.rot.x, frame.rot.y, frame.rot.z);
                f << buf;
            }
        }
        f << "end\n";
        
        return true;
    }

    // Convert WraithAnim to SmdAnim, referencing the SmdScene's bone list
    static SmdAnim ConvertAnim(const WraithAnim& wAnim, const SmdScene& refScene) {
        SmdAnim anim;
        anim.name = wAnim.AssetName;
        anim.fps = wAnim.FrameRate;
        anim.loop = wAnim.Looping;

        int origFrames = (int)wAnim.FrameCount();
        if (origFrames < 1) origFrames = 1;
        bool hasLoopFrame = (anim.loop && origFrames > 1);
        anim.frames = origFrames + (hasLoopFrame ? 1 : 0);

        std::vector<std::string> boneNames;
        for (auto& b : refScene.bones)
            boneNames.push_back(b.name);
        int nBones = (int)boneNames.size();
        anim.data.resize(anim.frames, std::vector<SmdAnim::Frame>(nBones));

        // Phase 1: default all frames to reference pose
        for (int fi = 0; fi < anim.frames; fi++) {
            for (int bi = 0; bi < nBones; bi++) {
                anim.data[fi][bi].pos = refScene.bones[bi].pos;
                anim.data[fi][bi].rot = refScene.bones[bi].rot;
            }
        }

        // Phase 2: overlay position keys
        for (auto& [boneName, keys] : wAnim.AnimationPositionKeys) {
            int bi = -1;
            for (int i = 0; i < nBones; i++) {
                if (boneNames[i] == boneName) { bi = i; break; }
            }
            if (bi < 0) continue;
            for (auto& key : keys) {
                int fi = (int)key.Frame;
                if (fi < origFrames)
                    anim.data[fi][bi].pos = { key.Value.x, key.Value.y, key.Value.z };
            }
        }

        // Phase 3: overlay rotation keys
        for (auto& [boneName, keys] : wAnim.AnimationRotationKeys) {
            int bi = -1;
            for (int i = 0; i < nBones; i++) {
                if (boneNames[i] == boneName) { bi = i; break; }
            }
            if (bi < 0) continue;
            for (auto& key : keys) {
                int fi = (int)key.Frame;
                if (fi < origFrames) {
                    Quat q = key.Value;
                    anim.data[fi][bi].rot = q.ToEuler();
                }
            }
        }

        // Phase 4: interpolate position between keyframes (linear)
        for (auto& [boneName, keys] : wAnim.AnimationPositionKeys) {
            int bi = -1;
            for (int i = 0; i < nBones; i++) {
                if (boneNames[i] == boneName) { bi = i; break; }
            }
            if (bi < 0 || keys.size() < 2) continue;
            for (size_t ki = 0; ki + 1 < keys.size(); ki++) {
                int f0 = (int)keys[ki].Frame;
                int f1 = (int)keys[ki + 1].Frame;
                if (f1 <= f0) continue;
                Vec3 v0 = { keys[ki].Value.x, keys[ki].Value.y, keys[ki].Value.z };
                Vec3 v1 = { keys[ki + 1].Value.x, keys[ki + 1].Value.y, keys[ki + 1].Value.z };
                double gap = (double)(f1 - f0);
                for (int f = f0 + 1; f < f1 && f < origFrames; f++) {
                    double t = (double)(f - f0) / gap;
                    Vec3 mw3 = { v0.x + (v1.x - v0.x) * t, v0.y + (v1.y - v0.y) * t, v0.z + (v1.z - v0.z) * t };
                    anim.data[f][bi].pos = mw3;
                }
            }
        }

        // Phase 5: SLERP rotation between keyframes
        for (auto& [boneName, keys] : wAnim.AnimationRotationKeys) {
            int bi = -1;
            for (int i = 0; i < nBones; i++) {
                if (boneNames[i] == boneName) { bi = i; break; }
            }
            if (bi < 0 || keys.size() < 2) continue;
            for (size_t ki = 0; ki + 1 < keys.size(); ki++) {
                int f0 = (int)keys[ki].Frame;
                int f1 = (int)keys[ki + 1].Frame;
                if (f1 <= f0) continue;
                Quat q0 = keys[ki].Value;
                Quat q1 = keys[ki + 1].Value;
                double dot = q0.x * q1.x + q0.y * q1.y + q0.z * q1.z + q0.w * q1.w;
                if (dot < 0) { q1 = { -q1.x, -q1.y, -q1.z, -q1.w }; dot = -dot; }
                double gap = (double)(f1 - f0);
                for (int f = f0 + 1; f < f1 && f < origFrames; f++) {
                    double t = (double)(f - f0) / gap, k0, k1;
                    if (dot > 0.9999) { k0 = 1.0 - t; k1 = t; }
                    else { double so = std::sqrt(1.0 - dot * dot), om = std::atan2(so, dot); k0 = std::sin((1.0 - t) * om) / so; k1 = std::sin(t * om) / so; }
                    Quat q = { k0*q0.x + k1*q1.x, k0*q0.y + k1*q1.y, k0*q0.z + k1*q1.z, k0*q0.w + k1*q1.w };
                    anim.data[f][bi].rot = q.ToEuler();
                }
            }
        }

        // Phase 6: unwrap Euler angles across frames to prevent discontinuities
        for (int bi = 0; bi < nBones; bi++) {
            for (int fi = 1; fi < anim.frames; fi++) {
                auto& prev = anim.data[fi - 1][bi].rot;
                auto& curr = anim.data[fi][bi].rot;
                auto uw = [](double& v, double r) { while (v - r > 3.14159265) v -= 6.2831853; while (v - r < -3.14159265) v += 6.2831853; };
                uw(curr.x, prev.x); uw(curr.y, prev.y); uw(curr.z, prev.z);
            }
        }

        // Phase 7: duplicate frame 0 at end for smooth GoldSrc looping
        if (hasLoopFrame) anim.data.back() = anim.data[0];

        return anim;
    }
};
