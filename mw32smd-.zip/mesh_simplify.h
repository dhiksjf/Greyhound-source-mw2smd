#pragma once
#include "wraith_types.h"
#include <unordered_set>
#include <unordered_map>
#include <functional>
#include <numeric>
#include <set>
#include <map>
#include <cstdio>
#include <iostream>

// ===========================================================================
//  GoldSrc Constants
// ===========================================================================
static constexpr int GS_MAX_BONES     = 128;
static constexpr int GS_MAX_TRIS      = 20000;
static constexpr int GS_MAX_VERTS     = 4096;
static constexpr int GS_MAX_BODY_NAME = 32;
static constexpr int GS_MAX_TEX_NAME  = 64;

// ===========================================================================
//  MESH REPAIR — diagnostics and auto-fix for mesh integrity issues
//  Detects and fixes: inverted winding, wrong-direction normals, 
//  vertex position duplicates (welding), open edges, non-manifold edges
// ===========================================================================
class MeshRepair {
public:
    struct Report {
        int invertedTris = 0;
        int flippedNormals = 0;
        int weldedVerts = 0;
        int openEdges = 0;
        int nonManifoldEdges = 0;
        int holes = 0;
    };

    Report Run(SmdScene& s) {
        Report rpt;
        std::cout << "=== Mesh Repair ===\n";

        // 1. Winding check — majority vote per texture group
        //    Compute face normal and compare with vertex normals;
        //    if most face normals point opposite the vertex normals, flip winding.
        FixWinding(s, rpt);

        // 2. Normal repair — force vertex normals to point with face normal
        RepairNormals(s, rpt);

        // 3. Vertex welding — snap nearby positions and merge
        WeldVertices(s, rpt);

        // 4. Edge diagnostics (requires welded vertex IDs)
        ComputeEdgeDiagnostics(s, rpt);

        // Summary
        if (rpt.invertedTris)    std::cout << "  Inverted tris fixed: " << rpt.invertedTris << "\n";
        if (rpt.flippedNormals)  std::cout << "  Normals flipped outward: " << rpt.flippedNormals << "\n";
        if (rpt.weldedVerts)     std::cout << "  Welded duplicate verts: " << rpt.weldedVerts << "\n";
        if (rpt.openEdges)       std::cout << "  Open edges (used by 1 tri): " << rpt.openEdges << "\n";
        if (rpt.nonManifoldEdges) std::cout << "  Non-manifold edges (used by >2 tris): " << rpt.nonManifoldEdges << "\n";
        if (!rpt.invertedTris && !rpt.flippedNormals && !rpt.weldedVerts &&
            !rpt.openEdges && !rpt.nonManifoldEdges)
            std::cout << "  No issues found.\n";

        return rpt;
    }

private:
    // Hash grid key for spatial vertex lookup
    struct GridKey {
        int64_t gx, gy, gz;
        bool operator==(const GridKey& o) const { return gx == o.gx && gy == o.gy && gz == o.gz; }
    };
    struct GridHash {
        size_t operator()(const GridKey& k) const {
            return std::hash<int64_t>{}(k.gx) ^ (std::hash<int64_t>{}(k.gy) << 17) ^ (std::hash<int64_t>{}(k.gz) << 34);
        }
    };

    // Convert a position to a grid key at given snap resolution
    static GridKey PosToKey(const Vec3& p, double snap) {
        auto toInt = [snap](double v) -> int64_t { return (int64_t)(v / snap + (v < 0 ? -0.5 : 0.5)); };
        return { toInt(p.x), toInt(p.y), toInt(p.z) };
    }

    void FixWinding(SmdScene& s, Report& rpt) {
        // Group tris by texture to handle each mesh independently
        std::map<std::string, std::vector<int>> texGroups;
        for (int i = 0; i < (int)s.tris.size(); i++)
            texGroups[s.tris[i].tex].push_back(i);

        for (auto& [tex, indices] : texGroups) {
            int flipped = 0, total = 0;
            for (int idx : indices) {
                auto& tri = s.tris[idx];
                Vec3 e1 = tri.v[1].pos - tri.v[0].pos;
                Vec3 e2 = tri.v[2].pos - tri.v[0].pos;
                Vec3 fn = e1.cross(e2);
                double len = fn.len();
                if (len < 1e-10) continue;
                fn = fn.norm();
                double agree = 0;
                for (int i = 0; i < 3; i++)
                    agree += tri.v[i].nrm.x * fn.x + tri.v[i].nrm.y * fn.y + tri.v[i].nrm.z * fn.z;
                if (agree < 0) flipped++;
                total++;
            }
            if (total > 0 && flipped > total / 2) {
                for (int idx : indices)
                    std::swap(s.tris[idx].v[1], s.tris[idx].v[2]);
                rpt.invertedTris += (int)indices.size();
                std::cout << "  Winding: texture '" << tex << "' " << flipped << "/" << total
                          << " inverted — flipped " << indices.size() << " tris\n";
            }
        }
    }

    void RepairNormals(SmdScene& s, Report& rpt) {
        for (auto& tri : s.tris) {
            Vec3 e1 = tri.v[1].pos - tri.v[0].pos;
            Vec3 e2 = tri.v[2].pos - tri.v[0].pos;
            Vec3 fn = e1.cross(e2);
            double len = fn.len();
            if (len < 1e-10) continue;
            fn = fn.norm();
            for (auto& v : tri.v) {
                bool bad = v.nrm.zero() || v.nrm.len() < 0.3 || v.nrm.len() > 1.7 ||
                           !std::isfinite(v.nrm.x) || !std::isfinite(v.nrm.y) || !std::isfinite(v.nrm.z);
                if (bad) {
                    v.nrm = fn;
                    rpt.flippedNormals++;
                } else {
                    double d = v.nrm.x * fn.x + v.nrm.y * fn.y + v.nrm.z * fn.z;
                    if (d < -0.1) {
                        v.nrm = { -v.nrm.x, -v.nrm.y, -v.nrm.z };
                        rpt.flippedNormals++;
                    }
                }
            }
        }
    }

    void WeldVertices(SmdScene& s, Report& rpt) {
        const double SNAP_POS = 0.0005;
        // Hash grid: position + bone key → canonical vertex data
        struct CanonicalVert {
            Vec3 pos, nrm;
            Vec2 uv;
            int bone;
            int count;
        };
        std::unordered_map<GridKey, int, GridHash> grid;
        std::vector<CanonicalVert> canon;

        for (auto& tri : s.tris) {
            for (int i = 0; i < 3; i++) {
                auto& v = tri.v[i];
                GridKey k = PosToKey(v.pos, SNAP_POS);
                k.gz = k.gz * 131 + v.bone; // also key by bone
                auto it = grid.find(k);
                if (it != grid.end()) {
                    int cidx = it->second;
                    auto& cv = canon[cidx];
                    // Average normal
                    cv.nrm.x = (cv.nrm.x * cv.count + v.nrm.x) / (cv.count + 1);
                    cv.nrm.y = (cv.nrm.y * cv.count + v.nrm.y) / (cv.count + 1);
                    cv.nrm.z = (cv.nrm.z * cv.count + v.nrm.z) / (cv.count + 1);
                    double nl = cv.nrm.len();
                    if (nl > 1e-10) { cv.nrm.x /= nl; cv.nrm.y /= nl; cv.nrm.z /= nl; }
                    cv.count++;
                    // Copy canonical data back to vertex
                    v.pos = cv.pos;
                    v.nrm = cv.nrm;
                    v.uv = cv.uv;
                    v.bone = cv.bone;
                    rpt.weldedVerts++;
                } else {
                    int cidx = (int)canon.size();
                    canon.push_back({ v.pos, v.nrm, v.uv, v.bone, 1 });
                    grid[k] = cidx;
                }
            }
        }
    }

    void ComputeEdgeDiagnostics(SmdScene& s, Report& rpt) {
        if (s.tris.empty()) return;

        // Build unique vertex index from position weld grid
        const double SNAP_EDGE = 0.001;
        std::unordered_map<GridKey, int, GridHash> vtxGrid;
        auto getVIdx = [&](const Vec3& p) -> int {
            GridKey k = PosToKey(p, SNAP_EDGE);
            auto [it, ins] = vtxGrid.emplace(k, (int)vtxGrid.size());
            return it->second;
        };

        // Build edge map: edge (minIdx, maxIdx) → count
        struct EdgeInfo { int count = 0; };
        std::map<std::pair<int, int>, EdgeInfo> edges;
        for (auto& tri : s.tris) {
            int vi[3];
            for (int i = 0; i < 3; i++)
                vi[i] = getVIdx(tri.v[i].pos);
            for (int i = 0; i < 3; i++) {
                int a = vi[i], b = vi[(i + 1) % 3];
                if (a > b) std::swap(a, b);
                edges[{a, b}].count++;
            }
        }

        // Classify edges
        for (auto& [edge, info] : edges) {
            if (info.count == 1) rpt.openEdges++;
            else if (info.count > 2) rpt.nonManifoldEdges++;
        }
    }
};

// ===========================================================================
//  Remove isolated triangle fragments (disconnected from main body)
// ===========================================================================
static std::vector<SmdTri> RemoveIsolatedFragments(std::vector<SmdTri> tris, float keepFraction = 0.05f) {
    int n = (int)tris.size();
    if (n < 10) return tris;

    std::vector<int> par(n);
    std::iota(par.begin(), par.end(), 0);
    std::function<int(int)> find = [&](int x) -> int { return par[x] == x ? x : par[x] = find(par[x]); };
    auto unite = [&](int a, int b) { par[find(a)] = find(b); };

    const double SNAP = 0.02;
    struct PKey { int x, y, z; bool operator==(const PKey& o) const { return x == o.x && y == o.y && z == o.z; } };
    struct PKH { size_t operator()(const PKey& k) const { return std::hash<int>{}(k.x) ^ (std::hash<int>{}(k.y) << 13) ^ (std::hash<int>{}(k.z) << 26); } };
    std::unordered_map<PKey, int, PKH> vtx2tri;
    vtx2tri.reserve(n * 3);
    for (int ti = 0; ti < n; ti++) {
        for (auto& v : tris[ti].v) {
            PKey k{ (int)(v.pos.x / SNAP), (int)(v.pos.y / SNAP), (int)(v.pos.z / SNAP) };
            auto [it, ins] = vtx2tri.emplace(k, ti);
            if (!ins) unite(ti, it->second);
        }
    }

    std::unordered_map<int, int> compSz;
    for (int i = 0; i < n; i++) compSz[find(i)]++;
    int maxSz = 0;
    for (auto& [c, sz] : compSz) maxSz = std::max(maxSz, sz);
    int minSz = std::max(3, (int)(maxSz * keepFraction));

    std::vector<SmdTri> result;
    result.reserve(n);
    int removed = 0;
    for (int i = 0; i < n; i++) {
        if (compSz[find(i)] >= minSz) result.push_back(tris[i]);
        else removed++;
    }
    if (removed)
        std::cout << "    Fragment filter: removed " << removed << " isolated tris, " << result.size() << " remain\n";
    return result;
}

// ===========================================================================
//  VERTEX CLUSTER DECIMATOR  — grid-based O(n) reduction
//  Ported from fbx2smd.cpp v6.0
// ===========================================================================
class VertexClusterDecimator {
public:
    int Decimate(std::vector<SmdTri>& tris, int targetVerts) {
        if (tris.empty()) return 0;
        int curVerts = CountUniqueVerts(tris);
        if (curVerts <= targetVerts) return curVerts;

        std::cout << "    VCluster: " << curVerts << " verts -> target " << targetVerts << "\n";

        int N = std::max(2, (int)std::ceil(std::cbrt((double)targetVerts)));

        for (; N >= 2; N--) {
            std::vector<SmdTri> result = ClusterPass(tris, N);
            int v = CountUniqueVerts(result);
            if (v <= targetVerts) {
                int origT = (int)tris.size();
                tris = std::move(result);
                std::cout << "    VCluster N=" << N << ": " << origT << " tris -> " << (int)tris.size() << " tris, " << v << " verts\n";
                return v;
            }
        }

        {
            std::vector<SmdTri> result = ClusterPass(tris, 1);
            int v = CountUniqueVerts(result);
            tris = std::move(result);
            std::cout << "    VCluster hit N=1 floor: " << v << " verts\n";
            return v;
        }
    }

private:
    static int CountUniqueVerts(const std::vector<SmdTri>& tris) {
        struct VKey { int px, py, pz, nx, ny, nz, tu, tv, bone; bool operator==(const VKey& o) const { return px == o.px && py == o.py && pz == o.pz && nx == o.nx && ny == o.ny && nz == o.nz && tu == o.tu && tv == o.tv && bone == o.bone; } };
        struct VKH { size_t operator()(const VKey& k) const { size_t h = (size_t)k.px * 2654435761u; h ^= (size_t)k.py * 40503u; h ^= (size_t)k.pz * 0x9e3779b9u; h ^= (size_t)k.nx * 0x6b43a9b5u; h ^= (size_t)k.ny * 0x27d4eb2fu; h ^= (size_t)k.nz * 1000003u; h ^= (size_t)k.tu * 999983u; h ^= (size_t)k.tv * 7919u; h ^= (size_t)k.bone * 104729u; return h; } };
        std::unordered_set<VKey, VKH> seen;
        seen.reserve(tris.size() * 3);
        for (auto& t : tris) for (auto& v : t.v)
            seen.insert({ (int)(v.pos.x * 10000), (int)(v.pos.y * 10000), (int)(v.pos.z * 10000),
                          (int)(v.nrm.x * 10000), (int)(v.nrm.y * 10000), (int)(v.nrm.z * 10000),
                          (int)(v.uv.u * 65536), (int)(v.uv.v * 65536), v.bone });
        return (int)seen.size();
    }

    std::vector<SmdTri> ClusterPass(const std::vector<SmdTri>& src, int N) {
        double mnx = 1e18, mny = 1e18, mnz = 1e18;
        double mxx = -1e18, mxy = -1e18, mxz = -1e18;
        for (auto& t : src) for (auto& v : t.v) {
            mnx = std::min(mnx, v.pos.x); mny = std::min(mny, v.pos.y); mnz = std::min(mnz, v.pos.z);
            mxx = std::max(mxx, v.pos.x); mxy = std::max(mxy, v.pos.y); mxz = std::max(mxz, v.pos.z);
        }
        double rx = mxx - mnx, ry = mxy - mny, rz = mxz - mnz;
        if (rx < 1e-10) rx = 1.0; if (ry < 1e-10) ry = 1.0; if (rz < 1e-10) rz = 1.0;

        struct CKey { int cx, cy, cz, bone; bool operator==(const CKey& o) const { return cx == o.cx && cy == o.cy && cz == o.cz && bone == o.bone; } };
        struct CKH { size_t operator()(const CKey& k) const { return std::hash<int>{}(k.cx) ^ (std::hash<int>{}(k.cy) << 11) ^ (std::hash<int>{}(k.cz) << 22) ^ (std::hash<int>{}(k.bone) << 5); } };

        struct Rep { double px, py, pz, nx, ny, nz; double tu, tv; int bone; int count; };
        std::unordered_map<CKey, Rep, CKH> clusters;
        clusters.reserve(std::min((size_t)(N * N * N + 1), src.size() * 3));

        auto cellFor = [&](const SmdVert& v) -> CKey {
            int cx = (int)((v.pos.x - mnx) / rx * N);
            int cy = (int)((v.pos.y - mny) / ry * N);
            int cz = (int)((v.pos.z - mnz) / rz * N);
            cx = std::clamp(cx, 0, N - 1);
            cy = std::clamp(cy, 0, N - 1);
            cz = std::clamp(cz, 0, N - 1);
            return { cx, cy, cz, v.bone };
        };

        // Pass 1: accumulate
        for (auto& t : src) for (int i = 0; i < 3; i++) {
            auto& v = t.v[i];
            CKey k = cellFor(v);
            auto it = clusters.find(k);
            if (it == clusters.end()) {
                clusters[k] = { v.pos.x, v.pos.y, v.pos.z, v.nrm.x, v.nrm.y, v.nrm.z, v.uv.u, v.uv.v, v.bone, 1 };
            } else {
                Rep& r = it->second;
                r.px += v.pos.x; r.py += v.pos.y; r.pz += v.pos.z;
                r.nx += v.nrm.x; r.ny += v.nrm.y; r.nz += v.nrm.z;
                r.count++;
            }
        }
        for (auto& [k, r] : clusters) {
            double c = r.count;
            r.px /= c; r.py /= c; r.pz /= c;
            r.nx /= c; r.ny /= c; r.nz /= c;
            double nl = std::sqrt(r.nx * r.nx + r.ny * r.ny + r.nz * r.nz);
            if (nl > 1e-10) { r.nx /= nl; r.ny /= nl; r.nz /= nl; }
            else { r.nx = 0; r.ny = 0; r.nz = 1; }
        }

        // Pass 2: rebuild triangles
        std::vector<SmdTri> result;
        result.reserve(src.size());
        double cellSize = std::max({ rx, ry, rz }) / N;
        double maxAllowedEdge = cellSize * 4.0;

        for (auto& t : src) {
            CKey k0 = cellFor(t.v[0]);
            CKey k1 = cellFor(t.v[1]);
            CKey k2 = cellFor(t.v[2]);
            if (k0 == k1 || k1 == k2 || k0 == k2) continue;

            SmdTri nt;
            nt.tex = t.tex;
            nt.sourceMesh = t.sourceMesh;

            auto applyRep = [&](SmdVert& dst, const CKey& ck) {
                auto& r = clusters[ck];
                dst.pos = { r.px, r.py, r.pz };
                dst.nrm = { r.nx, r.ny, r.nz };
                dst.uv.u = (float)r.tu; dst.uv.v = (float)r.tv;
                dst.bone = r.bone;
            };
            applyRep(nt.v[0], k0);
            applyRep(nt.v[1], k1);
            applyRep(nt.v[2], k2);

            // Stretch guard
            double e01 = (nt.v[0].pos - nt.v[1].pos).len();
            double e12 = (nt.v[1].pos - nt.v[2].pos).len();
            double e20 = (nt.v[2].pos - nt.v[0].pos).len();
            if (e01 > maxAllowedEdge || e12 > maxAllowedEdge || e20 > maxAllowedEdge)
                continue;

            // Recompute face normal
            Vec3 faceN = (nt.v[1].pos - nt.v[0].pos).cross(nt.v[2].pos - nt.v[0].pos);
            if (faceN.lenSq() < 1e-14) continue;
            faceN = faceN.norm();

            double agree = t.v[0].nrm.dot(faceN) + t.v[1].nrm.dot(faceN) + t.v[2].nrm.dot(faceN);
            if (agree < 0.0) {
                std::swap(nt.v[1], nt.v[2]);
                faceN = -faceN;
            }

            nt.v[0].nrm = nt.v[1].nrm = nt.v[2].nrm = faceN;
            result.push_back(nt);
        }

        result = RemoveIsolatedFragments(std::move(result), 0.02f);
        return result;
    }
};

// ===========================================================================
//  GOLDSCRC OPTIMIZER  — enforces all GoldSrc model limits
//  Ported from fbx2smd.cpp GSOptimizer v4.1
// ===========================================================================
class GSOptimizer {
public:
    void Run(SmdScene& s, int maxBones = GS_MAX_BONES, bool forceLowPoly = false, int lowPolyTarget = 3500) {
        std::cout << "=== GoldSrc Optimizer ===\n";
        MeshRepair mr;
        mr.Run(s);
        FixNormals(s);
        RemoveDegen(s);
        ReduceBones(s, maxBones);
        EnforceGSLimits(s, forceLowPoly, lowPolyTarget);
        ValidateNames(s);
        Stats(s);
    }

    static int CountUniqueVerts(const std::vector<SmdTri>& tris) {
        struct VKey { int px, py, pz, nx, ny, nz, tu, tv, bone; bool operator==(const VKey& o) const { return px == o.px && py == o.py && pz == o.pz && nx == o.nx && ny == o.ny && nz == o.nz && tu == o.tu && tv == o.tv && bone == o.bone; } };
        struct VKH { size_t operator()(const VKey& k) const { size_t h = std::hash<int>{}(k.px); h ^= std::hash<int>{}(k.py) * 2654435761u; h ^= std::hash<int>{}(k.pz) * 40503u; h ^= std::hash<int>{}(k.nx) * 0x9e3779b9u; h ^= std::hash<int>{}(k.ny) * 0x6b43a9b5u; h ^= std::hash<int>{}(k.nz) * 0x27d4eb2fu; h ^= std::hash<int>{}(k.tu) * 1000003u; h ^= std::hash<int>{}(k.tv) * 999983u; h ^= std::hash<int>{}(k.bone) * 7919u; return h; } };
        std::unordered_set<VKey, VKH> seen;
        seen.reserve(tris.size() * 3);
        for (auto& t : tris) for (auto& v : t.v)
            seen.insert({ (int)(v.pos.x * 10000), (int)(v.pos.y * 10000), (int)(v.pos.z * 10000),
                          (int)(v.nrm.x * 10000), (int)(v.nrm.y * 10000), (int)(v.nrm.z * 10000),
                          (int)(v.uv.u * 65536), (int)(v.uv.v * 65536), v.bone });
        return (int)seen.size();
    }

private:
    void FixNormals(SmdScene& s) {
        int n = 0;
        for (auto& t : s.tris) {
            Vec3 fn = (t.v[1].pos - t.v[0].pos).cross(t.v[2].pos - t.v[0].pos).norm();
            for (auto& v : t.v) {
                if (v.nrm.zero() || v.nrm.len() < 0.3 || v.nrm.len() > 1.7 ||
                    !std::isfinite(v.nrm.x) || !std::isfinite(v.nrm.y) || !std::isfinite(v.nrm.z)) {
                    v.nrm = fn; n++;
                }
            }
        }
        if (n) std::cout << "  Fixed " << n << " bad normals\n";
    }

    void RemoveDegen(SmdScene& s) {
        int b = (int)s.tris.size();
        s.tris.erase(std::remove_if(s.tris.begin(), s.tris.end(), [](const SmdTri& t) {
            return (t.v[1].pos - t.v[0].pos).cross(t.v[2].pos - t.v[0].pos).lenSq() < 1e-12;
        }), s.tris.end());
        if (int rm = b - (int)s.tris.size())
            std::cout << "  Removed " << rm << " degenerate tris\n";
    }

    void ReduceBones(SmdScene& s, int maxBones) {
        int n = (int)s.bones.size();
        if (n <= maxBones) {
            std::cout << "  Bones: " << n << " / " << maxBones << "\n";
            return;
        }
        std::cout << "  Bones " << n << " > " << maxBones << " — merging excess into nearest in-budget ancestor\n";
        std::vector<int> remap(n);
        std::iota(remap.begin(), remap.end(), 0);
        for (int i = maxBones; i < n; i++) {
            int p = s.bones[i].parent;
            while (p >= maxBones && p >= 0) p = s.bones[p].parent;
            remap[i] = (p < 0 || p >= maxBones) ? 0 : p;
        }
        for (auto& t : s.tris) for (auto& v : t.v) {
            v.bone = remap[v.bone];
            for (auto& bw : v.weights) bw.bone = remap[bw.bone];
            std::map<int, float> merged;
            for (auto& bw : v.weights) merged[bw.bone] += bw.weight;
            float tot = 0; for (auto& [b2, w] : merged) tot += w;
            v.weights.clear();
            for (auto& [b2, w] : merged) v.weights.push_back({ b2, tot > 0 ? w / tot : 0.f });
            std::sort(v.weights.begin(), v.weights.end(),
                      [](const BoneWeight& a, const BoneWeight& b) { return a.weight > b.weight; });
            if (!v.weights.empty()) v.bone = v.weights[0].bone;
        }
        for (auto& a : s.anims) for (auto& f : a.data)
            if ((int)f.size() > maxBones) f.resize(maxBones);
        s.bones.resize(maxBones);
        std::cout << "  Bones reduced to " << maxBones << "\n";
    }

    // Subdivide a piece with a single median split along its longest axis.
    // Returns two pieces (or one if too small to split).
    static std::vector<std::vector<SmdTri>> SplitPiece(const std::vector<SmdTri>& t) {
        if (t.size() <= 6) return { t };
        double mnx = 1e18, mny = 1e18, mnz = 1e18;
        double mxx = -1e18, mxy = -1e18, mxz = -1e18;
        double sx = 0, sy = 0, sz = 0;
        for (auto& tri : t) for (auto& vt : tri.v) {
            mnx = std::min(mnx, vt.pos.x); mny = std::min(mny, vt.pos.y); mnz = std::min(mnz, vt.pos.z);
            mxx = std::max(mxx, vt.pos.x); mxy = std::max(mxy, vt.pos.y); mxz = std::max(mxz, vt.pos.z);
            sx += vt.pos.x; sy += vt.pos.y; sz += vt.pos.z;
        }
        double n3 = (double)t.size() * 3.0;
        double cx = sx / n3, cy = sy / n3, cz = sz / n3;
        double rx = mxx - mnx, ry = mxy - mny, rzz = mxz - mnz;
        int axis = (rx >= ry && rx >= rzz) ? 0 : (ry >= rzz ? 1 : 2);
        double mid = (axis == 0) ? cx : (axis == 1) ? cy : cz;
        std::vector<SmdTri> lo, hi;
        lo.reserve(t.size() / 2 + 1); hi.reserve(t.size() / 2 + 1);
        for (auto& tri : t) {
            double tc = ((axis == 0) ? (tri.v[0].pos.x + tri.v[1].pos.x + tri.v[2].pos.x)
                      : (axis == 1) ? (tri.v[0].pos.y + tri.v[1].pos.y + tri.v[2].pos.y)
                      : (tri.v[0].pos.z + tri.v[1].pos.z + tri.v[2].pos.z)) / 3.0;
            (tc <= mid ? lo : hi).push_back(tri);
        }
        if (lo.empty() || hi.empty()) {
            size_t half = t.size() / 2;
            lo.assign(t.begin(), t.begin() + half);
            hi.assign(t.begin() + half, t.end());
        }
        return { std::move(lo), std::move(hi) };
    }

    void EnforceGSLimits(SmdScene& s, bool forceLowPoly, int lowPolyTarget) {
        const int MAX_BODIES = 32;
        int triTarget = forceLowPoly ? std::min(lowPolyTarget, GS_MAX_TRIS) : GS_MAX_TRIS;
        int nBones = (int)s.bones.size();

        int curTris = (int)s.tris.size();
        int curVerts = CountUniqueVerts(s.tris);

        std::cout << "  Pre-optimize:  " << curTris << " tris,  " << curVerts << " unique verts\n";
        std::cout << "  Limits: " << GS_MAX_VERTS << " verts/body, " << MAX_BODIES << " bodies, " << nBones << " bones\n";

        // If total verts exceed max budget (32*4096), warn but do NOT decimate —
        // the models will fill to capacity. Only decimate as absolute last resort.
        int totalBudget = MAX_BODIES * GS_MAX_VERTS;
        if (curVerts > totalBudget) {
            std::cout << "  NOTICE: " << curVerts << " total verts exceeds " << totalBudget << " budget — "
                      << "bodies will be at or near capacity\n";
        }

        if (curTris <= triTarget && curVerts <= GS_MAX_VERTS) {
            std::cout << "  Within single-body GoldSrc limits\n";
            s.bodyBins.clear();
            return;
        }

        std::cout << "  Over single-body limit — multi-body split\n";

        // Phase 1: Geometric split — recursively split each source mesh
        // until every piece fits within GS_MAX_VERTS
        std::function<std::vector<std::vector<SmdTri>>(std::vector<SmdTri>)> splitFit;
        splitFit = [&](std::vector<SmdTri> t) -> std::vector<std::vector<SmdTri>> {
            int v = CountUniqueVerts(t);
            int tt = (int)t.size();
            if (v <= GS_MAX_VERTS && tt <= triTarget) return { std::move(t) };
            if (t.size() <= 6) return { std::move(t) };
            auto halves = SplitPiece(t);
            auto La = splitFit(std::move(halves[0]));
            auto Lb = splitFit(std::move(halves[1]));
            La.insert(La.end(), std::make_move_iterator(Lb.begin()), std::make_move_iterator(Lb.end()));
            return La;
        };

        // Split per source mesh
        std::map<std::string, std::vector<SmdTri>> byMesh;
        for (auto& t : s.tris) byMesh[t.sourceMesh].push_back(t);
        std::cout << "  Source meshes: " << byMesh.size() << "\n";

        std::vector<std::vector<SmdTri>> bins;
        for (auto& [mname, mtris] : byMesh) {
            auto pieces = splitFit(mtris);
            std::cout << "  Mesh '" << mname << "' -> " << pieces.size() << " piece(s)\n";
            for (auto& p : pieces) bins.push_back(std::move(p));
        }
        std::cout << "  Pieces after geo-split: " << bins.size() << "\n";

        // Phase 2: Fill to exactly MAX_BODIES bodygroups for maximum detail granularity.
        // Subdivide the largest pieces until we reach MAX_BODIES or no piece is splittable.
        while ((int)bins.size() < MAX_BODIES) {
            // Find largest splittable piece
            int largestIdx = -1;
            int largestTris = 0;
            for (int i = 0; i < (int)bins.size(); i++) {
                int sz = (int)bins[i].size();
                if (sz >= 12 && sz > largestTris) {
                    largestTris = sz;
                    largestIdx = i;
                }
            }
            if (largestIdx < 0) break; // nothing more to split
            auto halves = SplitPiece(bins[largestIdx]);
            bins[largestIdx] = std::move(halves[0]);
            bins.push_back(std::move(halves[1]));
        }

        // If more than MAX_BODIES, repeatedly merge the two smallest pieces
        // until we reach exactly MAX_BODIES.
        while ((int)bins.size() > MAX_BODIES) {
            std::sort(bins.begin(), bins.end(),
                [](auto& a, auto& b) { return a.size() < b.size(); });
            bins[1].insert(bins[1].end(), bins[0].begin(), bins[0].end());
            bins.erase(bins.begin());
        }
        s.bodyBins = std::move(bins);

        // Final report
        std::cout << "  Bodygroup result: " << s.bodyBins.size() << " group(s)\n";
        for (int bi = 0; bi < (int)s.bodyBins.size(); bi++) {
            int v = CountUniqueVerts(s.bodyBins[bi]);
            int t = (int)s.bodyBins[bi].size();
            bool vOK = (v <= GS_MAX_VERTS), tOK = (t <= GS_MAX_TRIS);
            std::cout << "  Body " << bi << ": " << t << " tris, " << v << " verts  " << (vOK && tOK ? "[OK]" : (!vOK ? "[FAIL verts]" : "[FAIL tris]")) << "\n";
        }

        // Re-assemble for remaining processing (QC, etc.)
        s.tris.clear();
        for (auto& bin : s.bodyBins)
            s.tris.insert(s.tris.end(), bin.begin(), bin.end());
    }

    void ValidateNames(SmdScene& s) {
        for (auto& b : s.bones) {
            if ((int)b.name.size() > GS_MAX_BODY_NAME) {
                std::cout << "  Bone name too long: '" << b.name << "' — truncated to " << GS_MAX_BODY_NAME << " chars\n";
                b.name = b.name.substr(0, GS_MAX_BODY_NAME - 5);
            }
        }

        // Deduplicate bone names
        std::unordered_map<std::string, int> seen;
        int dupes = 0;
        for (auto& b : s.bones) {
            auto it = seen.find(b.name);
            if (it == seen.end()) {
                seen[b.name] = 1;
            } else {
                int n = ++(it->second);
                std::string suffix = "_" + std::to_string(n);
                std::string base = b.name.substr(0, std::max(1, GS_MAX_BODY_NAME - (int)suffix.size()));
                b.name = base + suffix;
                seen[b.name] = 1;
                dupes++;
            }
        }
        if (dupes) std::cout << "  Renamed " << dupes << " duplicate bone name(s)\n";

        // Validate texture names
        std::set<std::string> texNames;
        for (auto& t : s.tris) texNames.insert(t.tex);
        for (auto& tx : texNames)
            if ((int)tx.size() > GS_MAX_TEX_NAME)
                std::cout << "  Texture name too long: '" << tx << "' (" << tx.size() << " chars)\n";
    }

    static int CountBodyVerts(const std::vector<SmdTri>& tris) {
        struct VKey { int px, py, pz, nx, ny, nz, tu, tv, bone; bool operator==(const VKey& o) const { return px == o.px && py == o.py && pz == o.pz && nx == o.nx && ny == o.ny && nz == o.nz && tu == o.tu && tv == o.tv && bone == o.bone; } };
        struct VKH { size_t operator()(const VKey& k) const { size_t h = (size_t)k.px * 2654435761u; h ^= (size_t)k.py * 40503u; h ^= (size_t)k.pz * 0x9e3779b9u; h ^= (size_t)k.nx * 0x6b43a9b5u; h ^= (size_t)k.ny * 0x27d4eb2fu; h ^= (size_t)k.nz * 1000003u; h ^= (size_t)k.tu * 999983u; h ^= (size_t)k.tv * 7919u; h ^= (size_t)k.bone * 104729u; return h; } };
        std::unordered_set<VKey, VKH> seen;
        seen.reserve(tris.size() * 3);
        for (auto& t : tris) for (auto& v : t.v)
            seen.insert({ (int)(v.pos.x * 10000), (int)(v.pos.y * 10000), (int)(v.pos.z * 10000),
                          (int)(v.nrm.x * 10000), (int)(v.nrm.y * 10000), (int)(v.nrm.z * 10000),
                          (int)(v.uv.u * 65536), (int)(v.uv.v * 65536), v.bone });
        return (int)seen.size();
    }

    void Stats(SmdScene& s) {
        bool bOK = ((int)s.bones.size() <= GS_MAX_BONES);
        int totalTris = 0;
        bool allPass = true;

        if (!s.bodyBins.empty()) {
            for (int bi = 0; bi < (int)s.bodyBins.size(); bi++) {
                int v = CountBodyVerts(s.bodyBins[bi]);
                int t = (int)s.bodyBins[bi].size();
                totalTris += t;
                bool vOK = (v <= GS_MAX_VERTS), tOK = (t <= GS_MAX_TRIS);
                if (!vOK || !tOK) allPass = false;
                std::cout << "  Body " << bi << ": " << t << " tris, " << v << " unique verts  " << (vOK && tOK ? "[PASS]" : (!vOK ? "[FAIL verts]" : "[FAIL tris]")) << "\n";
            }
            std::cout << "  Total tris (all bodies): " << totalTris << "\n";
        } else {
            // Single body
            int maxV = CountBodyVerts(s.tris);
            bool vOK = (maxV <= GS_MAX_VERTS);
            bool tOK = ((int)s.tris.size() <= GS_MAX_TRIS);
            std::cout << "  Single body: " << (int)s.tris.size() << " tris, " << maxV << " unique verts  " << (vOK && tOK ? "[PASS]" : (!vOK ? "[FAIL verts]" : "[FAIL tris]")) << "\n";
        }
        std::cout << "  Bones: " << s.bones.size() << "/" << GS_MAX_BONES << " " << (bOK ? "[PASS]" : "[FAIL]") << "\n";
        std::cout << (allPass && bOK ? "  ALL LIMITS PASSED — model is CS 1.6 ready!\n" : "  SOME LIMITS EXCEEDED — studiomdl may produce errors\n");
    }
};
