#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <cmath>

// ===========================================================================
//  Math types
// ===========================================================================
struct Vec2 { double u = 0, v = 0; };

struct Vec3 {
    double x = 0, y = 0, z = 0;
    Vec3() = default;
    Vec3(double x_, double y_, double z_) : x(x_), y(y_), z(z_) {}
    Vec3 operator+(const Vec3& o) const { return { x + o.x, y + o.y, z + o.z }; }
    Vec3 operator-(const Vec3& o) const { return { x - o.x, y - o.y, z - o.z }; }
    Vec3 operator*(double s) const { return { x * s, y * s, z * s }; }
    Vec3 operator-() const { return { -x, -y, -z }; }
    double dot(const Vec3& o) const { return x * o.x + y * o.y + z * o.z; }
    Vec3 cross(const Vec3& o) const { return { y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x }; }
    double lenSq() const { return x * x + y * y + z * z; }
    double len() const { return std::sqrt(lenSq()); }
    Vec3 norm() const { double l = len(); return l < 1e-10 ? Vec3{ 0,0,1 } : Vec3{ x / l, y / l, z / l }; }
    bool zero() const { return lenSq() < 1e-12; }
    bool operator==(const Vec3& o) const { return std::abs(x - o.x) < 1e-5 && std::abs(y - o.y) < 1e-5 && std::abs(z - o.z) < 1e-5; }
};

struct Quat {
    double x = 0, y = 0, z = 0, w = 1;
    Quat() = default;
    Quat(double x_, double y_, double z_, double w_) : x(x_), y(y_), z(z_), w(w_) {}
    Vec3 ToEuler() const {
        double n = std::sqrt(x * x + y * y + z * z + w * w);
        if (n < 1e-10) return {};
        double qx = x / n, qy = y / n, qz = z / n, qw = w / n;
        double sr = 2 * (qw * qx + qy * qz), cr = 1 - 2 * (qx * qx + qy * qy);
        double rx = std::atan2(sr, cr);
        double sp = 2 * (qw * qy - qz * qx);
        double ry = (std::abs(sp) >= 1) ? std::copysign(3.14159265358979323846 / 2.0, sp) : std::asin(sp);
        double sy = 2 * (qw * qz + qx * qy), cy = 1 - 2 * (qy * qy + qz * qz);
        double rz = std::atan2(sy, cy);
        return { rx, ry, rz };
    }
    static Quat FromEuler(double rx, double ry, double rz) {
        double cx = std::cos(rx * 0.5), sx = std::sin(rx * 0.5);
        double cy = std::cos(ry * 0.5), sy = std::sin(ry * 0.5);
        double cz = std::cos(rz * 0.5), sz = std::sin(rz * 0.5);
        return {
            sx * cy * cz - cx * sy * sz,
            cx * sy * cz + sx * cy * sz,
            cx * cy * sz - sx * sy * cz,
            cx * cy * cz + sx * sy * sz
        };
    }
    Quat operator*(const Quat& o) const {
        return {
            w * o.x + x * o.w + y * o.z - z * o.y,
            w * o.y - x * o.z + y * o.w + z * o.x,
            w * o.z + x * o.y - y * o.x + z * o.w,
            w * o.w - x * o.x - y * o.y - z * o.z
        };
    }
    Quat Conjugate() const { return { -x, -y, -z, w }; }
};

struct BoneWeight { int bone; float weight; };

// ===========================================================================
//  SMD internal types (matching fbx2smd.cpp proven structures)
// ===========================================================================
struct SmdVert {
    Vec3 pos, nrm;
    Vec2 uv;
    int bone = 0;
    std::vector<BoneWeight> weights;
};

struct SmdTri {
    SmdVert v[3];
    std::string tex;
    std::string sourceMesh;
};

struct SmdBone {
    int index = -1;
    std::string name;
    int parent = -1;
    Vec3 pos;
    Vec3 rot;
    struct { Vec3 mn, mx; bool valid = false; } bbox;
};

struct SmdAnim {
    std::string name;
    int frames = 0;
    float fps = 30.0f;
    bool loop = false;
    struct Frame { Vec3 pos, rot; };
    std::vector<std::vector<Frame>> data; // [frame][bone]
};

struct SmdScene {
    std::vector<SmdBone> bones;
    std::vector<SmdTri>  tris;
    std::vector<SmdAnim> anims;
    struct { Vec3 mn, mx; bool valid = false; } bbox;
    std::vector<std::vector<SmdTri>> bodyBins;
    std::string modelName;
};

// ===========================================================================
//  Wraith types (for SEModel/SEAnim parsing)
// ===========================================================================
struct WraithVertexWeight {
    uint32_t BoneIndex = 0;
    float Weight = 0;
};

struct WraithVertex {
    Vec3 Position;
    Vec3 Normal;
    std::vector<Vec2> UVLayers;
    uint8_t Color[4] = { 255,255,255,255 };
    std::vector<WraithVertexWeight> Weights;
};

struct WraithFace {
    uint32_t Index1, Index2, Index3;
};

struct WraithSubmesh {
    std::vector<WraithVertex> Vertices;
    std::vector<WraithFace> Faces;
    std::vector<int32_t> MaterialIndices;
};

struct WraithMaterial {
    std::string MaterialName;
    std::string DiffuseMapName;
    std::string NormalMapName;
    std::string SpecularMapName;
};

struct WraithBone {
    std::string TagName;
    int32_t BoneParent = -1;
    Vec3 LocalPosition;
    Quat LocalRotation;
    Vec3 GlobalPosition;
    Quat GlobalRotation;
    Vec3 BoneScale{ 1,1,1 };
};

struct WraithModel {
    std::string AssetName;
    std::vector<WraithBone> Bones;
    std::vector<WraithSubmesh> Submeshes;
    std::vector<WraithMaterial> Materials;
    std::vector<std::string> BlendShapes;
};

enum class WraithAnimType : uint8_t {
    Absolute = 0, Additive = 1, Relative = 2, Delta = 3
};

template<class T> struct WraithAnimFrame {
    uint32_t Frame;
    T Value;
};

struct WraithAnim {
    std::string AssetName;
    WraithAnimType AnimType = WraithAnimType::Absolute;
    bool Looping = false;
    float FrameRate = 30.0f;
    std::unordered_map<std::string, std::vector<WraithAnimFrame<Vec3>>> AnimationPositionKeys;
    std::unordered_map<std::string, std::vector<WraithAnimFrame<Quat>>> AnimationRotationKeys;
    std::unordered_map<std::string, std::vector<WraithAnimFrame<Vec3>>> AnimationScaleKeys;
    std::unordered_map<std::string, std::vector<uint32_t>> AnimationNotetracks;
    std::unordered_map<std::string, WraithAnimType> AnimationBoneModifiers;

    uint32_t FrameCount() const {
        uint32_t maxF = 0;
        for (auto& [k, v] : AnimationPositionKeys)
            for (auto& f : v) if (f.Frame > maxF) maxF = f.Frame;
        for (auto& [k, v] : AnimationRotationKeys)
            for (auto& f : v) if (f.Frame > maxF) maxF = f.Frame;
        for (auto& [k, v] : AnimationScaleKeys)
            for (auto& f : v) if (f.Frame > maxF) maxF = f.Frame;
        return maxF + 1;
    }
    uint32_t BoneCount() const {
        std::unordered_set<std::string> all;
        for (auto& [k, v] : AnimationPositionKeys) all.insert(k);
        for (auto& [k, v] : AnimationRotationKeys) all.insert(k);
        for (auto& [k, v] : AnimationScaleKeys) all.insert(k);
        return (uint32_t)all.size();
    }
    std::unordered_set<std::string> Bones() const {
        std::unordered_set<std::string> all;
        for (auto& [k, v] : AnimationPositionKeys) all.insert(k);
        for (auto& [k, v] : AnimationRotationKeys) all.insert(k);
        for (auto& [k, v] : AnimationScaleKeys) all.insert(k);
        return all;
    }
    uint32_t NotificationCount() const {
        uint32_t n = 0;
        for (auto& [k, v] : AnimationNotetracks) n += (uint32_t)v.size();
        return n;
    }
};

// ===========================================================================
//  IWI → DDS types  
// ===========================================================================
struct XImageDDS {
    int8_t* DataBuffer = nullptr;
    uint32_t DataSize = 0;
    ~XImageDDS() { delete[] DataBuffer; }
    XImageDDS() = default;
    XImageDDS(const XImageDDS&) = delete;
    XImageDDS& operator=(const XImageDDS&) = delete;
    XImageDDS(XImageDDS&& o) noexcept : DataBuffer(o.DataBuffer), DataSize(o.DataSize) { o.DataBuffer = nullptr; o.DataSize = 0; }
    XImageDDS& operator=(XImageDDS&& o) noexcept { std::swap(DataBuffer, o.DataBuffer); std::swap(DataSize, o.DataSize); return *this; }
};
