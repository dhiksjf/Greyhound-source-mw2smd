// ===========================================================================
//  mw32smd v1.0 — MW3 (Modern Warfare 3) SEModel/SEAnim/IWI → GoldSrc SMD/QC/BMP
//
//  Converts MW3 model/animation/texture files extracted via Greyhound into
//  GoldSrc (CS 1.6 / Half-Life) SMD + QC + BMP format.
//
//  Input:  .semodel (binary)  — model data
//          .seanim  (binary)  — animation data (optional)
//          .iwi     (binary)  — texture data (optional)
//
//  Output: .smd (reference)   — one per body
//          .smd (animation)   — one per animation
//          .qc                — studiomdl compile script
//          .bmp               — decompressed textures
//
//  GoldSrc Limits Enforced:
//    - Single bone per vertex (dominant weight)
//    - ≤ 4096 unique verts (pos+nrm+uv+bone) per $body file
//    - ≤ 20000 tris per $body file
//    - ≤ 128 bones total
//    - UV coordinates clamped to [0,1]
//    - Vertex clustering decimation
//    - Automatic geometric split + bin-packing for multi-body
//    - Degenerate triangle removal
//    - Normal fixup
//    - Bone reduction
// ===========================================================================

#define NOMINMAX
#include <windows.h>
#include <ole2.h>
#include <gdiplus.h>
#pragma comment(lib, "gdiplus.lib")

#include "semodel_reader.h"
#include "seanim_reader.h"
#include "iwi_to_bmp.h"
#include "smd_writer.h"
#include "qc_writer.h"
#include "mesh_simplify.h"

#include <iostream>
#include <fstream>
#include <filesystem>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <cstring>
#include <algorithm>

namespace fs = std::filesystem;
using namespace Gdiplus;

// ===========================================================================
//  Helper functions
// ===========================================================================

// Convert PNG (or any GDI+-readable image) to 8-bit paletted BMP (required by Sven Co-op studiomdl)
static constexpr int MAX_TEX_RESOLUTION = 1024;

static bool ConvertImageToBMP(const std::string& src, const std::string& dst) {
    Bitmap* srcBmp = Bitmap::FromFile(std::wstring(src.begin(), src.end()).c_str());
    if (!srcBmp || srcBmp->GetLastStatus() != Ok) { delete srcBmp; return false; }
    int w = (int)srcBmp->GetWidth(), h = (int)srcBmp->GetHeight();
    if (w <= 0 || h <= 0) { delete srcBmp; return false; }
    // Downscale if texture exceeds GoldSrc max resolution
    Bitmap* bmp = srcBmp;
    if (w > MAX_TEX_RESOLUTION || h > MAX_TEX_RESOLUTION) {
        int nw = w, nh = h;
        if (nw > MAX_TEX_RESOLUTION) { nh = nh * MAX_TEX_RESOLUTION / nw; nw = MAX_TEX_RESOLUTION; }
        if (nh > MAX_TEX_RESOLUTION) { nw = nw * MAX_TEX_RESOLUTION / nh; nh = MAX_TEX_RESOLUTION; }
        std::cout << "    Resized " << w << "x" << h << " -> " << nw << "x" << nh << "\n";
        bmp = new Bitmap(nw, nh);
        Graphics g(bmp);
        g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
        g.DrawImage(srcBmp, 0, 0, nw, nh);
        delete srcBmp;
        w = nw; h = nh;
    }
    // Lock and read RGBA pixels
    Rect rct(0, 0, w, h);
    BitmapData bd;
    if (bmp->LockBits(&rct, ImageLockModeRead, PixelFormat32bppARGB, &bd) != Ok) { delete bmp; return false; }
    std::vector<uint8_t> rgba(w * h * 4);
    for (int y = 0; y < h; y++) {
        memcpy(&rgba[y * w * 4], (uint8_t*)bd.Scan0 + y * bd.Stride, w * 4);
    }
    bmp->UnlockBits(&bd);
    delete bmp;

    // Build 256-color palette: simple popularity algorithm
    // Count color frequency (using a 5-bit color cube for hash)
    struct ColorCount { uint8_t r, g, b; int count; };
    std::map<int, ColorCount> freq;
    for (int i = 0; i < w * h; i++) {
        int key = ((rgba[i * 4] >> 3) << 10) | ((rgba[i * 4 + 1] >> 3) << 5) | (rgba[i * 4 + 2] >> 3);
        auto it = freq.find(key);
        if (it == freq.end()) {
            freq[key] = { rgba[i * 4], rgba[i * 4 + 1], rgba[i * 4 + 2], 1 };
        } else {
            it->second.count++;
            // Accumulate color for averaging
            it->second.r = (uint8_t)((it->second.r * (it->second.count - 1) + rgba[i * 4]) / it->second.count);
            it->second.g = (uint8_t)((it->second.g * (it->second.count - 1) + rgba[i * 4 + 1]) / it->second.count);
            it->second.b = (uint8_t)((it->second.b * (it->second.count - 1) + rgba[i * 4 + 2]) / it->second.count);
        }
    }
    // Sort by frequency descending, take top 256
    std::vector<ColorCount> pal;
    for (auto& kv : freq) pal.push_back(kv.second);
    std::sort(pal.begin(), pal.end(), [](auto& a, auto& b) { return a.count > b.count; });
    if ((int)pal.size() > 256) pal.resize(256);
    // Pad to 256 entries
    while ((int)pal.size() < 256) pal.push_back({ 0, 0, 0, 0 });

    // Build 32^3 color cube lookup table for O(1) nearest-color mapping
    std::vector<uint8_t> lut(32 * 32 * 32);
    for (int ri = 0; ri < 32; ri++) {
        for (int gi = 0; gi < 32; gi++) {
            for (int bi = 0; bi < 32; bi++) {
                int best = 0, bestDist = INT_MAX;
                int rr = (ri << 3) | (ri >> 2), gg = (gi << 3) | (gi >> 2), bb = (bi << 3) | (bi >> 2);
                for (int pi = 0; pi < 256; pi++) {
                    int dr = rr - pal[pi].r, dg = gg - pal[pi].g, db = bb - pal[pi].b;
                    int d = dr * dr + dg * dg + db * db;
                    if (d < bestDist) { bestDist = d; best = pi; }
                }
                lut[(ri << 10) | (gi << 5) | bi] = (uint8_t)best;
            }
        }
    }
    // Map pixels to nearest palette color via LUT
    std::vector<uint8_t> idx(w * h);
    for (int i = 0; i < w * h; i++) {
        int ri = rgba[i * 4] >> 3, gi = rgba[i * 4 + 1] >> 3, bi = rgba[i * 4 + 2] >> 3;
        idx[i] = lut[(ri << 10) | (gi << 5) | bi];
    }

    // Write 8-bit BMP
    int stride = ((w + 3) / 4) * 4;
    uint32_t hdrSz = 14 + 40 + 256 * 4;
    uint32_t fileSz = hdrSz + stride * h;
    std::ofstream f(dst, std::ios::binary);
    if (!f) return false;
    auto w16 = [&](uint16_t v) { f.write((char*)&v, 2); };
    auto w32 = [&](uint32_t v) { f.write((char*)&v, 4); };
    f.write("BM", 2);
    w32(fileSz); w16(0); w16(0); w32(hdrSz);
    w32(40); w32((uint32_t)w); w32((uint32_t)h);
    w16(1); w16(8); w32(0); w32(stride * h);
    w32(2835); w32(2835); w32(256); w32(0);
    for (auto& c : pal) { f.put((char)c.b); f.put((char)c.g); f.put((char)c.r); f.put(0); }
    std::vector<uint8_t> row(stride, 0);
    for (int y = h - 1; y >= 0; y--) {
        for (int x = 0; x < w; x++) row[x] = idx[y * w + x];
        f.write((char*)row.data(), stride);
    }
    return true;
}

// ===========================================================================
//  Compute global transforms for all bones in a WraithModel
//  (fills GlobalPosition/GlobalRotation from LocalPosition/LocalRotation)
//  Uses iterative approach to handle any parent ordering.
// ===========================================================================
static void ComputeGlobalTransforms(WraithModel& wm) {
    std::vector<bool> done(wm.Bones.size(), false);
    for (int iter = 0; iter < (int)wm.Bones.size() * 2; iter++) {
        for (size_t i = 0; i < wm.Bones.size(); i++) {
            if (done[i]) continue;
            auto& b = wm.Bones[i];
            if (b.BoneParent < 0) {
                b.GlobalPosition = b.LocalPosition;
                b.GlobalRotation = b.LocalRotation;
                done[i] = true;
            } else if ((size_t)b.BoneParent < wm.Bones.size() && done[b.BoneParent]) {
                auto& pb = wm.Bones[b.BoneParent];
                b.GlobalRotation = pb.GlobalRotation * b.LocalRotation;
                Quat pv(b.LocalPosition.x, b.LocalPosition.y, b.LocalPosition.z, 0);
                Quat rpv = pb.GlobalRotation * pv * pb.GlobalRotation.Conjugate();
                b.GlobalPosition = { pb.GlobalPosition.x + rpv.x, pb.GlobalPosition.y + rpv.y, pb.GlobalPosition.z + rpv.z };
                done[i] = true;
            }
        }
    }
}

// ===========================================================================
//  Merge a weapon model into a primary (arms/hands) model
//  The weapon's root bone gets parented under attachBone in the primary.
// ===========================================================================
static bool MergeWraithModels(WraithModel& primary, const WraithModel& weapon,
    const std::string& attachBone, float scale)
{
    // Ensure global transforms are computed for both models
    // (primary may already have them; compute if missing)
    bool primaryHasGlobal = false;
    for (auto& b : primary.Bones)
        if (!b.GlobalPosition.zero() || b.GlobalRotation.w != 1 || b.GlobalRotation.x != 0 || b.GlobalRotation.y != 0 || b.GlobalRotation.z != 0)
            { primaryHasGlobal = true; break; }
    if (!primaryHasGlobal) ComputeGlobalTransforms(primary);

    bool weaponHasGlobal = false;
    WraithModel wmWeapon = weapon; // mutable copy
    for (auto& b : wmWeapon.Bones)
        if (!b.GlobalPosition.zero() || b.GlobalRotation.w != 1 || b.GlobalRotation.x != 0 || b.GlobalRotation.y != 0 || b.GlobalRotation.z != 0)
            { weaponHasGlobal = true; break; }
    if (!weaponHasGlobal) ComputeGlobalTransforms(wmWeapon);

    // Find attachment bone index in primary
    int attachIdx = -1;
    for (size_t i = 0; i < primary.Bones.size(); i++)
        if (primary.Bones[i].TagName == attachBone) { attachIdx = (int)i; break; }
    if (attachIdx < 0) {
        std::cerr << "ERROR: Attachment bone \"" << attachBone << "\" not found in primary model\n";
        return false;
    }

    int primaryBoneCount = (int)primary.Bones.size();
    int weaponBoneCount = (int)wmWeapon.Bones.size();

    // Build remap table: old weapon bone index -> merged bone index
    std::vector<int> weaponToMerged(weaponBoneCount);
    for (int i = 0; i < weaponBoneCount; i++)
        weaponToMerged[i] = primaryBoneCount + i;

    // Find weapon root (first bone with parent=-1)
    int weaponRootIdx = -1;
    for (int i = 0; i < weaponBoneCount; i++)
        if (wmWeapon.Bones[i].BoneParent < 0) { weaponRootIdx = i; break; }
    if (weaponRootIdx < 0) weaponRootIdx = 0; // fallback

    // Get attachment bone's global transform
    Vec3 attPos = primary.Bones[attachIdx].GlobalPosition;
    Quat attRot = primary.Bones[attachIdx].GlobalRotation;
    Quat invAttRot = attRot.Conjugate();

    // Merge bones: reparent weapon root under attachBone
    for (int i = 0; i < weaponBoneCount; i++) {
        WraithBone wb = wmWeapon.Bones[i];

        if (i == weaponRootIdx) {
            wb.BoneParent = attachIdx;

            // Compute local transform relative to attachBone
            Vec3 weaponPos = wb.GlobalPosition;
            Quat weaponRot = wb.GlobalRotation;

            // Local rotation: Qlocal = inv(attachRot) * weaponRot
            wb.LocalRotation = invAttRot * weaponRot;

            // Local position: Plocal = inv(attachRot) * (weaponPos - attachPos)
            Vec3 diff = { weaponPos.x - attPos.x, weaponPos.y - attPos.y, weaponPos.z - attPos.z };
            Quat pv(diff.x, diff.y, diff.z, 0);
            Quat rpv = invAttRot * pv * attRot; // rotated = invRot * pv * invRot^(-1) = invRot * pv * Rot
            wb.LocalPosition = { rpv.x, rpv.y, rpv.z };

            // Update global to be consistent
            wb.GlobalPosition = weaponPos;
            wb.GlobalRotation = weaponRot;
        } else {
            // Remap parent index
            int oldParent = wb.BoneParent;
            if (oldParent >= 0 && oldParent < weaponBoneCount)
                wb.BoneParent = weaponToMerged[oldParent];
        }

        // Apply scale to position data
        wb.LocalPosition.x *= scale;
        wb.LocalPosition.y *= scale;
        wb.LocalPosition.z *= scale;

        primary.Bones.push_back(wb);
    }

    // Merge submeshes with remapped bone indices
    for (auto& submesh : wmWeapon.Submeshes) {
        primary.Submeshes.push_back(submesh);
        auto& ns = primary.Submeshes.back();
        for (auto& v : ns.Vertices) {
            for (auto& w : v.Weights) {
                if (w.BoneIndex < (uint32_t)weaponBoneCount)
                    w.BoneIndex = (uint32_t)weaponToMerged[w.BoneIndex];
            }
        }
        // Scale vertex positions
        for (auto& v : ns.Vertices) {
            v.Position.x *= scale;
            v.Position.y *= scale;
            v.Position.z *= scale;
        }
    }

    // Merge materials (avoid duplicates by name)
    std::set<std::string> existingMatNames;
    for (auto& m : primary.Materials) existingMatNames.insert(m.MaterialName);
    for (auto& mat : wmWeapon.Materials) {
        if (existingMatNames.find(mat.MaterialName) == existingMatNames.end()) {
            primary.Materials.push_back(mat);
        }
    }

    return true;
}

static std::string ToLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), ::tolower);
    return s;
}

static std::string SanitizeName(const std::string& s, int maxLen = 64) {
    std::string out = s;
    for (char& c : out)
        if (!std::isalnum((unsigned char)c) && c != '_' && c != '-' && c != '.' && c != '#' && c != '[' && c != ']' && c != '(' && c != ')' && c != ' ')
            c = '_';
    if ((int)out.size() > maxLen) out = out.substr(0, maxLen);
    return out;
}

static void PrintUsage(const char* prog) {
    std::cerr << "Usage: " << prog << " --model <file.semodel> [options]\n\n";
    std::cerr << "Options:\n";
    std::cerr << "  --model <file>     SEModel file (required)\n";
    std::cerr << "  --merge-model <f>  Secondary SEModel to merge (e.g. weapon)\n";
    std::cerr << "  --attach-bone <s>  Bone in primary to attach merge (default: tag_weapon_left)\n";
    std::cerr << "  --anim <file>      SEAnim file (optional, repeat for multiple)\n";
    std::cerr << "  --texdir <dir>     Textures directory containing .iwi files\n";
    std::cerr << "  --outdir <dir>     Output directory (default: ./<modelname>)\n";
    std::cerr << "  --scale <float>    Model scale factor (default: 1.0)\n";
    std::cerr << "  --lowpoly          Force low-poly mode (<=3500 tris)\n";
    std::cerr << "  --maxtris <int>    Custom triangle budget (implies low-poly mode)\n";
    std::cerr << "  --flipv            Flip texture V coordinate (fix upside-down textures)\n";
    std::cerr << "  --maxbones <int>   Maximum bones (default: 128)\n";
    std::cerr << "  --modeldir <path>  Model dir in QC $modelname (default: models/player)\n";
    std::cerr << "  --help             Show this help\n\n";
    std::cerr << "Examples:\n";
    std::cerr << "  " << prog << " --model model.semodel --texdir textures/ --outdir output/\n";
    std::cerr << "  " << prog << " --model char.semodel --anim walk.seanim --anim idle.seanim\n";
    std::cerr << "  " << prog << " --model arms.semodel --merge-model weapon.semodel --anim fire.seanim\n";
}

// ===========================================================================
//  Convert WraithModel -> SmdScene
// ===========================================================================
static SmdScene WraithModelToSmdScene(const WraithModel& wm, float scale = 1.0f, bool flipV = false) {
    SmdScene scene;
    scene.modelName = wm.AssetName;

    // Convert bones
    for (size_t i = 0; i < wm.Bones.size(); i++) {
        auto& wb = wm.Bones[i];
        SmdBone sb;
        sb.index = (int)i;
        sb.name = SanitizeName(wb.TagName, 32);
        sb.parent = wb.BoneParent;

        Vec3 localPos = { wb.LocalPosition.x, wb.LocalPosition.y, wb.LocalPosition.z };
        Quat localRot = wb.LocalRotation;

        // Convert local rotation quaternion to Euler angles
        Vec3 euler = localRot.ToEuler();

        // Apply scale to position
        sb.pos = { localPos.x * scale, localPos.y * scale, localPos.z * scale };
        sb.rot = euler;

        scene.bones.push_back(sb);
    }

    // Convert meshes to triangles
    // Determine the dominant bone per vertex: weight with highest value
    auto getDominantBone = [](const std::vector<WraithVertexWeight>& weights) -> int {
        if (weights.empty()) return 0;
        int bestBone = weights[0].BoneIndex;
        float bestWeight = weights[0].Weight;
        for (auto& w : weights) {
            if (w.Weight > bestWeight) {
                bestWeight = w.Weight;
                bestBone = w.BoneIndex;
            }
        }
        return bestBone;
    };

    // Collect unique texture names from materials
    std::map<int, std::string> materialTextures; // material index -> texture name
    for (size_t mi = 0; mi < wm.Materials.size(); mi++) {
        auto& mat = wm.Materials[mi];
        std::string texName = mat.DiffuseMapName;
        if (texName.empty()) texName = mat.MaterialName;
        if (texName.empty()) texName = "tex_" + std::to_string(mi);
        // Convert to BMP name
        texName = QCWriter::TexStem(texName) + ".bmp";
        materialTextures[(int)mi] = texName;
    }

    // --- Phase 1: Detect inverted winding per submesh ---
    // SEModel (DirectX) uses CW winding; GoldSrc (OpenGL) expects CCW.
    // Compare face normals against vertex normals to detect.
    int totalVerts = 0;
    std::vector<bool> flipSubmesh;
    for (auto& mesh : wm.Submeshes) {
        int flipped = 0, total = 0;
        for (auto& face : mesh.Faces) {
            if (face.Index1 >= mesh.Vertices.size() || face.Index2 >= mesh.Vertices.size() || face.Index3 >= mesh.Vertices.size())
                continue;
            auto& v0 = mesh.Vertices[face.Index1];
            auto& v1 = mesh.Vertices[face.Index2];
            auto& v2 = mesh.Vertices[face.Index3];
            Vec3 e1 = { v1.Position.x - v0.Position.x, v1.Position.y - v0.Position.y, v1.Position.z - v0.Position.z };
            Vec3 e2 = { v2.Position.x - v0.Position.x, v2.Position.y - v0.Position.y, v2.Position.z - v0.Position.z };
            Vec3 fn = e1.cross(e2);
            double fnl = fn.len();
            if (fnl < 1e-10) continue;
            fn = fn.norm();
            Vec3 vn = { v0.Normal.x, v0.Normal.y, v0.Normal.z };
            double agree = vn.x * fn.x + vn.y * fn.y + vn.z * fn.z;
            if (agree < 0.0) flipped++;
            total++;
        }
        bool doFlip = (total > 0 && flipped > total / 2);
        flipSubmesh.push_back(doFlip);
        if (doFlip)
            std::cout << "  Submesh " << flipSubmesh.size() - 1 << ": inverted winding detected (" << flipped << "/" << total << ") — flipping\n";
    }

    // --- Phase 2: Convert triangles with correct winding ---
    int meshIdx = 0;
    for (auto& mesh : wm.Submeshes) {
        bool flip = (meshIdx < (int)flipSubmesh.size()) ? flipSubmesh[meshIdx] : false;
        for (auto& face : mesh.Faces) {
            SmdTri tri;
            uint32_t idx[3] = { face.Index1, face.Index2, face.Index3 };
            if (flip) std::swap(idx[1], idx[2]);
            for (int i = 0; i < 3; i++) {
                const WraithVertex* v = &mesh.Vertices[idx[i]];

                tri.v[i].pos = { v->Position.x * scale, v->Position.y * scale, v->Position.z * scale };
                tri.v[i].nrm = { v->Normal.x, v->Normal.y, v->Normal.z };
                if (!v->UVLayers.empty()) {
                    tri.v[i].uv.u = v->UVLayers[0].u;
                    tri.v[i].uv.v = flipV ? 1.0 - v->UVLayers[0].v : v->UVLayers[0].v;
                }
                tri.v[i].bone = getDominantBone(v->Weights);
                // Store full weight list
                for (auto& w : v->Weights)
                    tri.v[i].weights.push_back({ (int)w.BoneIndex, w.Weight });
            }

            // Determine texture from material index
            int matIdx = mesh.MaterialIndices.empty() ? -1 : mesh.MaterialIndices[0];
            if (matIdx >= 0 && matIdx < (int)wm.Materials.size())
                tri.tex = materialTextures[matIdx];
            else
                tri.tex = "default.bmp";

            // Assign source mesh name for geo-splitting
            tri.sourceMesh = wm.AssetName + "_mesh" + std::to_string(totalVerts);

            scene.tris.push_back(tri);
        }
        totalVerts += (int)mesh.Vertices.size();
    }

    // Compute bounding box
    for (auto& t : scene.tris) {
        for (auto& v : t.v) {
            if (!scene.bbox.valid) {
                scene.bbox.mn = scene.bbox.mx = v.pos;
                scene.bbox.valid = true;
            } else {
                scene.bbox.mn.x = std::min(scene.bbox.mn.x, v.pos.x);
                scene.bbox.mn.y = std::min(scene.bbox.mn.y, v.pos.y);
                scene.bbox.mn.z = std::min(scene.bbox.mn.z, v.pos.z);
                scene.bbox.mx.x = std::max(scene.bbox.mx.x, v.pos.x);
                scene.bbox.mx.y = std::max(scene.bbox.mx.y, v.pos.y);
                scene.bbox.mx.z = std::max(scene.bbox.mx.z, v.pos.z);
            }
        }
    }

    // Compute per-bone bounding boxes for hitbox generation
    for (auto& t : scene.tris) {
        for (auto& v : t.v) {
            int bi = v.bone;
            if (bi >= 0 && bi < (int)scene.bones.size()) {
                auto& bb = scene.bones[bi].bbox;
                if (!bb.valid) {
                    bb.mn = bb.mx = v.pos;
                    bb.valid = true;
                } else {
                    bb.mn.x = std::min(bb.mn.x, v.pos.x);
                    bb.mn.y = std::min(bb.mn.y, v.pos.y);
                    bb.mn.z = std::min(bb.mn.z, v.pos.z);
                    bb.mx.x = std::max(bb.mx.x, v.pos.x);
                    bb.mx.y = std::max(bb.mx.y, v.pos.y);
                    bb.mx.z = std::max(bb.mx.z, v.pos.z);
                }
            }
        }
    }

    return scene;
}

// ===========================================================================
//  Convert IWI textures in a directory to BMP
// ===========================================================================
static int ConvertTextures(const std::string& texDir, const std::string& outDir) {
    int count = 0;
    if (!fs::exists(texDir)) {
        std::cerr << "Texture directory not found: " << texDir << "\n";
        return 0;
    }

    for (auto& entry : fs::directory_iterator(texDir)) {
        if (!entry.is_regular_file()) continue;
        auto ext = ToLower(entry.path().extension().string());
        if (ext != ".iwi") continue;

        std::string stem = entry.path().stem().string();
        std::string bmpPath = outDir + "/" + QCWriter::TexStem(stem) + ".bmp";

        if (fs::exists(bmpPath)) {
            std::cout << "  [SKIP] " << stem << ".bmp already exists\n";
            count++;
            continue;
        }

        std::cout << "  Converting IWI: " << entry.path().filename() << " -> " << fs::path(bmpPath).filename() << "\n";
        if (IWIToBMP::Convert(entry.path().string(), bmpPath)) {
            count++;
            std::cout << "    OK\n";
        } else {
            std::cerr << "    FAILED: " << entry.path() << "\n";
        }
    }

    return count;
}

// ===========================================================================
//  Convert a single IWI file to BMP
// ===========================================================================
static bool ConvertTexture(const std::string& iwiPath, const std::string& bmpPath) {
    std::cout << "  Converting IWI: " << fs::path(iwiPath).filename() << " -> " << fs::path(bmpPath).filename() << "\n";
    if (IWIToBMP::Convert(iwiPath, bmpPath)) {
        std::cout << "    OK\n";
        return true;
    }
    std::cerr << "    FAILED: " << iwiPath << "\n";
    return false;
}

// ===========================================================================
//  Main
// ===========================================================================
int main(int argc, char* argv[]) {
    // Initialize GDI+ for PNG→BMP conversion
    GdiplusStartupInput gdiplusStartupInput;
    ULONG_PTR gdiplusToken;
    GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    std::string modelPath, texDir, outDir, modelDir = "models/player";
    std::string mergeModelPath, attachBone = "tag_weapon_left";
    std::vector<std::string> animPaths;
    float scale = 1.0f;
    bool lowPoly = false;
    bool flipV = false;
    int maxBones = 128;
    int maxTris = 0; // 0 = default budget

    // Parse CLI
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--help" || arg == "-h") {
            PrintUsage(argv[0]);
            return 0;
        } else if (arg == "--model" && i + 1 < argc) {
            modelPath = argv[++i];
        } else if (arg == "--merge-model" && i + 1 < argc) {
            mergeModelPath = argv[++i];
        } else if (arg == "--attach-bone" && i + 1 < argc) {
            attachBone = argv[++i];
        } else if (arg == "--anim" && i + 1 < argc) {
            animPaths.push_back(argv[++i]);
        } else if (arg == "--texdir" && i + 1 < argc) {
            texDir = argv[++i];
        } else if (arg == "--outdir" && i + 1 < argc) {
            outDir = argv[++i];
        } else if (arg == "--scale" && i + 1 < argc) {
            scale = (float)std::atof(argv[++i]);
        } else if (arg == "--lowpoly") {
            lowPoly = true;
        } else if (arg == "--flipv") {
            flipV = true;
        } else if (arg == "--maxtris" && i + 1 < argc) {
            maxTris = std::atoi(argv[++i]);
        } else if (arg == "--maxbones" && i + 1 < argc) {
            maxBones = std::atoi(argv[++i]);
        } else if (arg == "--modeldir" && i + 1 < argc) {
            modelDir = argv[++i];
        } else if (arg == "--model" || arg == "--merge-model" || arg == "--attach-bone" ||
                   arg == "--anim" || arg == "--texdir" || arg == "--outdir" ||
                   arg == "--scale" || arg == "--maxtris" || arg == "--maxbones" || arg == "--modeldir") {
            std::cerr << "Error: " << arg << " requires a value\n";
            return 1;
        } else {
            std::cerr << "Unknown option: " << arg << "\n";
            PrintUsage(argv[0]);
            return 1;
        }
    }

    if (modelPath.empty()) {
        std::cerr << "Error: --model is required\n";
        PrintUsage(argv[0]);
        return 1;
    }

    // Determine output directory
    if (outDir.empty()) {
        fs::path mp(modelPath);
        outDir = mp.parent_path().string() + "/" + mp.stem().string();
    }
    fs::create_directories(outDir);

    std::string baseName = SanitizeName(fs::path(modelPath).stem().string(), 64);

    std::cout << "\n=== mw32smd v1.0 — MW3 to GoldSrc Converter ===\n\n";
    std::cout << "Model:   " << modelPath << "\n";
    std::cout << "Output:  " << outDir << "\n";
    std::cout << "Scale:   " << scale << "\n";
    if (!texDir.empty()) std::cout << "Textures: " << texDir << "\n";
    if (!animPaths.empty()) {
        std::cout << "Anims:   ";
        for (auto& a : animPaths) std::cout << a << " ";
        std::cout << "\n";
    }
    std::cout << "\n";

    // ---- Step 1: Read SEModel ----
    std::cout << "--- Reading SEModel ---\n";
    WraithModel wm;
    {
        SEModelReader reader;
        if (!reader.Load(modelPath)) {
            std::cerr << "FAILED: Cannot load " << modelPath << "\n";
            return 1;
        }
        if (!reader.Read(wm)) {
            std::cerr << "FAILED: Cannot parse " << modelPath << "\n";
            return 1;
        }
        std::cout << "  Bones: " << wm.Bones.size() << "\n";
        std::cout << "  Submeshes: " << wm.Submeshes.size() << "\n";
        std::cout << "  Materials: " << wm.Materials.size() << "\n";
        int totalVerts = 0, totalFaces = 0;
        for (auto& m : wm.Submeshes) {
            totalVerts += (int)m.Vertices.size();
            totalFaces += (int)m.Faces.size();
        }
        std::cout << "  Total verts: " << totalVerts << "\n";
        std::cout << "  Total faces: " << totalFaces << "\n";
    }

    // ---- Step 1b: Merge secondary model (e.g. weapon) into primary (arms) ----
    if (!mergeModelPath.empty()) {
        std::cout << "\n--- Merging model: " << mergeModelPath << " ---\n";
        WraithModel wmMerge;
        {
            SEModelReader reader;
            if (!reader.Load(mergeModelPath)) {
                std::cerr << "FAILED: Cannot load " << mergeModelPath << "\n";
                return 1;
            }
            if (!reader.Read(wmMerge)) {
                std::cerr << "FAILED: Cannot parse " << mergeModelPath << "\n";
                return 1;
            }
            std::cout << "  Merge bones: " << wmMerge.Bones.size() << "\n";
            std::cout << "  Merge submeshes: " << wmMerge.Submeshes.size() << "\n";
            std::cout << "  Merge materials: " << wmMerge.Materials.size() << "\n";
        }
        if (MergeWraithModels(wm, wmMerge, attachBone, scale)) {
            std::cout << "  Merge OK — total bones: " << wm.Bones.size()
                << ", submeshes: " << wm.Submeshes.size()
                << ", materials: " << wm.Materials.size() << "\n";
        } else {
            std::cerr << "FAILED: Model merge could not attach to bone \"" << attachBone << "\"\n";
            return 1;
        }
    }

    // ---- Step 2: Convert to SmdScene ----
    std::cout << "\n--- Converting to SMD scene ---\n";
    SmdScene scene = WraithModelToSmdScene(wm, scale, flipV);
    std::cout << "  Tris: " << scene.tris.size() << "\n";
    std::cout << "  Bones: " << scene.bones.size() << "\n";

    // ---- Step 3: Read SEAnim files ----
    std::vector<SmdAnim> smdAnims;
    for (auto& animPath : animPaths) {
        std::cout << "\n--- Reading SEAnim: " << animPath << " ---\n";
        WraithAnim wa;
        SEAnimReader animReader;
        if (!animReader.Load(animPath)) {
            std::cerr << "FAILED: Cannot load " << animPath << "\n";
            continue;
        }
        if (!animReader.Read(wa)) {
            std::cerr << "FAILED: Cannot parse " << animPath << "\n";
            continue;
        }
        std::cout << "  Frames: " << wa.FrameCount() << "\n";
        std::cout << "  Bones: " << wa.BoneCount() << "\n";
        std::cout << "  FPS: " << wa.FrameRate << "\n";
        std::cout << "  Type: " << (wa.AnimType == WraithAnimType::Absolute ? "Absolute" : wa.AnimType == WraithAnimType::Additive ? "Additive" : wa.AnimType == WraithAnimType::Relative ? "Relative" : "Delta") << "\n";
        // Print key count summary for matched bones only
        for (auto& b : scene.bones) {
            auto pIt = wa.AnimationPositionKeys.find(b.name);
            auto rIt = wa.AnimationRotationKeys.find(b.name);
            int pCnt = (pIt != wa.AnimationPositionKeys.end()) ? (int)pIt->second.size() : 0;
            int rCnt = (rIt != wa.AnimationRotationKeys.end()) ? (int)rIt->second.size() : 0;
            if (pCnt > 0 || rCnt > 0)
                std::cout << "    Bone \"" << b.name << "\": pos_keys=" << pCnt << " rot_keys=" << rCnt << "\n";
        }
        // Show top animation bones NOT in model (to detect naming mismatch)
        std::map<std::string, int> animBones;
        for (auto& [k, v] : wa.AnimationPositionKeys) animBones[k] += (int)v.size();
        for (auto& [k, v] : wa.AnimationRotationKeys) animBones[k] += (int)v.size();
        std::vector<std::pair<int, std::string>> sorted;
        for (auto& [k, v] : animBones) {
            bool inModel = false;
            for (auto& b : scene.bones) if (b.name == k) { inModel = true; break; }
            if (!inModel) sorted.push_back({ v, k });
        }
        std::sort(sorted.begin(), sorted.end(), [](auto& a, auto& b) { return a.first > b.first; });
        for (int i = 0; i < std::min(5, (int)sorted.size()); i++)
            std::cout << "    [UNMATCHED] \"" << sorted[i].second << "\": " << sorted[i].first << " total keys\n";

        SmdAnim sa = SMDWriter::ConvertAnim(wa, scene);
        sa.name = fs::path(animPath).stem().string();
        smdAnims.push_back(sa);
    }

    // ---- Step 4: Convert textures ----
    std::vector<std::string> convertedTextures;
    std::set<std::string> texSet;
    if (!texDir.empty()) {
        std::cout << "\n--- Converting textures ---\n";
        // Find textures referenced by materials
        for (auto& mat : wm.Materials) {
            std::string texName = mat.DiffuseMapName;
            if (texName.empty()) texName = mat.MaterialName;
            if (texName.empty()) continue;
            std::string stem = QCWriter::TexStem(texName);
            std::string bmpPath = outDir + "/" + stem + ".bmp";

            // Scan texDir recursively for a matching texture file (.iwi or .png)
            bool found = false;
            if (fs::exists(texDir)) {
                for (auto& entry : fs::recursive_directory_iterator(texDir)) {
                    if (!entry.is_regular_file()) continue;
                    auto fstem = ToLower(entry.path().stem().string());
                    if (fstem == ToLower(stem)) {
                        auto ext = ToLower(entry.path().extension().string());
                        if (ext == ".iwi") {
                            if (!fs::exists(bmpPath))
                                if (ConvertTexture(entry.path().string(), bmpPath))
                                    convertedTextures.push_back(bmpPath);
                        } else if (ext == ".png" || ext == ".tga" || ext == ".jpg") {
                            if (!fs::exists(bmpPath)) {
                                std::cout << "  Converting: " << entry.path().filename() << " -> " << stem << ".bmp\n";
                                ConvertImageToBMP(entry.path().string(), bmpPath);
                            }
                        }
                        texSet.insert(stem + ".bmp");
                        found = true;
                        break;
                    }
                }
            }
            if (!found) {
                texSet.insert(stem + ".bmp");
            }
        }

        // Also scan for needed texture files in texdir and convert any not yet processed
        if (fs::exists(texDir)) {
            for (auto& entry : fs::recursive_directory_iterator(texDir)) {
                if (!entry.is_regular_file()) continue;
                auto ext = ToLower(entry.path().extension().string());
                if (ext != ".iwi" && ext != ".png" && ext != ".tga" && ext != ".jpg") continue;
                std::string stem = QCWriter::TexStem(entry.path().stem().string());
                std::string bmpName = stem + ".bmp";
                // Only convert if this texture is referenced by the model
                if (texSet.find(bmpName) == texSet.end()) continue;
                std::string bmpPath = outDir + "/" + bmpName;
                if (fs::exists(bmpPath)) continue;
                if (ext == ".iwi") {
                    if (ConvertTexture(entry.path().string(), bmpPath))
                        convertedTextures.push_back(bmpPath);
                } else if (ext == ".png" || ext == ".tga" || ext == ".jpg") {
                    std::cout << "  Converting: " << entry.path().filename() << " -> " << bmpName << "\n";
                    ConvertImageToBMP(entry.path().string(), bmpPath);
                }
            }
        }
    }

    // Collect texture names from the scene's triangles
    for (auto& t : scene.tris) {
        if (!t.tex.empty()) texSet.insert(t.tex);
    }

    std::cout << "\n=== Running GoldSrc Optimizer ===\n";
    GSOptimizer opt;
    if (maxTris > 0) {
        // Custom triangle budget implies low-poly mode with that target
        opt.Run(scene, maxBones, true, maxTris);
    } else {
        opt.Run(scene, maxBones, lowPoly);
    }

    // ---- Step 5: Write SMD files ----
    std::cout << "\n--- Writing SMD files ---\n";
    std::vector<std::string> bodyNames;
    std::string refSMDName = baseName + "_ref";

    if (scene.bodyBins.empty()) {
        // Single body
        std::string smdPath = outDir + "/" + refSMDName + ".smd";
        if (SMDWriter::WriteRefSMD(smdPath, scene)) {
            std::cout << "  Written: " << smdPath << "\n";
        } else {
            std::cerr << "  FAILED: " << smdPath << "\n";
        }
        bodyNames.push_back(refSMDName);
    } else {
        // Multi-body: write one SMD per body group
        // We need to build a separate SmdScene for each body
        for (size_t bi = 0; bi < scene.bodyBins.size(); bi++) {
            SmdScene bodyScene;
            bodyScene.bones = scene.bones;
            bodyScene.tris = scene.bodyBins[bi];
            bodyScene.bbox = scene.bbox;

            std::string bodyName = baseName + "_body" + std::to_string(bi);
            std::string smdPath = outDir + "/" + bodyName + ".smd";

            if (SMDWriter::WriteRefSMD(smdPath, bodyScene)) {
                std::cout << "  Written: " << smdPath << "\n";
            } else {
                std::cerr << "  FAILED: " << smdPath << "\n";
            }
            bodyNames.push_back(bodyName);
        }
        // Also write the full reference for fallback
        std::string smdPath = outDir + "/" + refSMDName + ".smd";
        SMDWriter::WriteRefSMD(smdPath, scene);
    }

    // ---- Step 6: Write animation SMD files ----
    if (smdAnims.empty()) {
        // Generate a 1-frame idle animation from the reference pose
        SmdAnim idle;
        idle.name = "idle";
        idle.fps = 30;
        idle.frames = 1;
        idle.loop = true;
        idle.data.resize(1);
        idle.data[0].resize(scene.bones.size());
        for (size_t bi = 0; bi < scene.bones.size(); bi++) {
            idle.data[0][bi].pos = scene.bones[bi].pos;
            idle.data[0][bi].rot = scene.bones[bi].rot;
        }
        smdAnims.push_back(idle);
    }
    for (auto& sa : smdAnims) {
        // Mirror QCWriter's naming exactly (strip last dot segment + same sanitizer)
        // so the written filename always matches the QC $sequence reference
        std::string stem = sa.name;
        auto dotPos = stem.find_last_of('.');
        if (dotPos != std::string::npos) stem = stem.substr(0, dotPos);
        std::string animName = QCWriter::SanitizeName(stem, 64);
        std::string animPath = outDir + "/" + animName + ".smd";
        if (SMDWriter::WriteAnimSMD(animPath, scene, sa)) {
            std::cout << "  Written anim: " << animPath << " (" << sa.frames << " frames @ " << (int)sa.fps << " fps)\n";
        } else {
            std::cerr << "  FAILED anim: " << animPath << "\n";
        }
    }

    // ---- Step 7: Write QC file ----
    std::cout << "\n--- Writing QC file ---\n";
    std::string qcPath = outDir + "/" + baseName + ".qc";
    if (QCWriter::WriteQC(qcPath, baseName, scene, bodyNames, smdAnims, texSet, modelDir)) {
        std::cout << "  Written: " << qcPath << "\n";
    } else {
        std::cerr << "  FAILED: " << qcPath << "\n";
    }

    GdiplusShutdown(gdiplusToken);

    std::cout << "\n=== Conversion complete! ===\n";
    std::cout << "Output directory: " << outDir << "\n";
    std::cout << "Compile with: studiomdl.exe " << outDir << "/" << baseName << ".qc\n\n";

    return 0;
}
