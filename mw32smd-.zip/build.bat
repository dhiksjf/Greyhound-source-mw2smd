@echo off
set SRC_DIR=C:\Users\MOI\DOWNLO~1\GREYHO~1\mw32smd
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvarsall.bat" x64
cd /d "%SRC_DIR%"
cl /nologo /EHsc /std:c++17 /Fe: mw32smd_new.exe mw32smd.cpp /link gdiplus.lib
if %ERRORLEVEL% EQU 0 (
    echo BUILD SUCCESS
) else (
    echo BUILD FAILED
)
