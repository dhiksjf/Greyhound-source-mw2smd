$ErrorActionPreference = "Continue"

$base = "C:\Users\MOI\Downloads\Greyhound-source (1)\Greyhound-source (1)"
$converter = "$base\mw32smd\mw32smd.exe"
$studiomdl = "C:\Users\MOI\Downloads\Meshy_AI_RL_07_Rocket_Battery_0702102556_generate\studiomdl.exe"
$xmodels = "$base\Greyhound-source-code\src\WraithXCOD\x64\Release\exported_files\modern_warfare_3\xmodels"
$xanims = "$base\Greyhound-source-code\src\WraithXCOD\x64\Release\exported_files\modern_warfare_3\xanims"
$texdir = "$xmodels\_images"
$outdir = "$base\mw32smd\batch_v2"

if (-not (Test-Path $converter)) { Write-Error "Converter not found: $converter"; exit 1 }
if (-not (Test-Path $studiomdl)) { Write-Error "studiomdl not found: $studiomdl"; exit 1 }
if (Test-Path $outdir) { Remove-Item -Recurse -Force $outdir }
New-Item -ItemType Directory -Force -Path $outdir | Out-Null
Copy-Item $studiomdl "$outdir\studiomdl.exe"

function Convert-Model {
    param($name, $extraArgs = "")
    $modelFile = "$xmodels\$name\${name}_LOD0.semodel"
    if (-not (Test-Path $modelFile)) { Write-Warning "SKIP $name — no LOD0.semodel"; return $false }
    $mdlOut = "$outdir\$name"
    New-Item -ItemType Directory -Force -Path $mdlOut | Out-Null
    Write-Host "[CONVERT] $name"
    & $converter --model $modelFile --texdir $texdir --outdir $mdlOut --modeldir "models/player" --maxbones 128 $extraArgs 2>&1 | ForEach-Object { Write-Host "  $_" }
    if ($LASTEXITCODE -ne 0) { Write-Warning "FAILED: $name (exit $LASTEXITCODE)"; return $false }
    return $true
}

function Convert-Merged {
    param($modelName, $mergeName, $outName, $animPrefix, $attachBone = "tag_weapon_left")
    $modelFile = "$xmodels\$modelName\${modelName}_LOD0.semodel"
    $mergeFile = "$xmodels\$mergeName\${mergeName}_LOD0.semodel"
    if (-not (Test-Path $mergeFile)) { Write-Warning "SKIP merged $outName — merge model not found"; return $false }
    $mdlOut = "$outdir\$outName"
    New-Item -ItemType Directory -Force -Path $mdlOut | Out-Null
    $animArgs = ""
    if ($animPrefix) {
        $animFiles = Get-ChildItem "$xanims" -Filter "${animPrefix}*.seanim" | ForEach-Object { "--anim `"$($_.FullName)`"" }
        $animArgs = $animFiles -join " "
    }
    Write-Host "[CONVERT-MERGED] $outName ($modelName + $mergeName)"
    & $converter --model $modelFile --merge-model $mergeFile --attach-bone $attachBone --texdir $texdir --outdir $mdlOut --modeldir "models/player" --maxbones 128 $animArgs 2>&1 | ForEach-Object { Write-Host "  $_" }
    if ($LASTEXITCODE -ne 0) { Write-Warning "FAILED merged: $outName (exit $LASTEXITCODE)"; return $false }
    return $true
}

$totalTime = Measure-Command {
# ===== PHASE 1: Props, characters, vehicles, misc =====
$group1 = @(
    "accessories_book_row01_paris","bc_militarytent_wood_table","body_chemwar_russian_assault_b",
    "body_hero_truck_delta","ch_missle_rack","com_airduct_02","com_bottle4",
    "com_cardboardbox01","com_cardboardbox01_open","com_cardboardbox06","com_cardboardbox_dusty_03",
    "com_computer_keyboard","com_office_book_beige_paper_folder","com_tin_round_flat",
    "com_water_fount_statue_v2","defaultvehicle","fx_shotgun_shell","grenade_bag",
    "head_airborne_a","head_delta_a","intel_laptop","ivy_vine_clump_root",
    "me_antenna","me_rebar01","mil_ammo_case_1",
    "projectile_bouncing_betty_trigger","projectile_cbu97_clusterbomb_shell",
    "projectile_cbu97_clusterbomb_tail","projectile_javelin_missile","projectile_m203grenade",
    "projectile_m67fraggrenade","projectile_m84_flashbang_grenade","projectile_rpg7",
    "projectile_tag","projectile_us_smoke_grenade","prop_large_generator",
    "prop_telephone_box","tag_turret","vehicle_ac130_low","vehicle_cobra_helicopter_d",
    "vehicle_f15_missile","viewhands_delta"
)
Write-Host "`n===== PHASE 1: $($group1.Count) props/chars/vehicles ====="
foreach ($m in $group1) { Convert-Model $m }

# ===== PHASE 2: Standalone weapons =====
$group2 = @(
    "weapon_aa12_sp_iw5","weapon_ak47_tactical","weapon_ak47_tactical_clip",
    "weapon_m67_grenade","weapon_mp5","weapon_mp5k_clip","weapon_mp5_clip",
    "weapon_mp5_clip_iw5","weapon_mp5_sp_iw5","weapon_rpg7"
)
Write-Host "`n===== PHASE 2: $($group2.Count) standalone weapons ====="
foreach ($m in $group2) { Convert-Model $m }

# ===== PHASE 3: Standalone viewmodels (no merge needed) =====
$group3 = @(
    "viewmodel_ak74u_black","viewmodel_desert_eagle_sp_iw5","viewmodel_m16",
    "viewmodel_m84","viewmodel_mp412","viewmodel_rpg7_rocket"
)
Write-Host "`n===== PHASE 3: $($group3.Count) standalone viewmodels ====="
foreach ($m in $group3) { Convert-Model $m }

# ===== PHASE 4: Merged viewmodels =====
Write-Host "`n===== PHASE 4: Merged viewmodel+weapon conversions ====="

# 4a: AA12 — merge into viewhands_delta (no weapon geo in base)
Convert-Merged "viewhands_delta" "weapon_aa12_sp_iw5" "viewmodel_aa12_merged" "viewmodel_aa12_"

# 4b: M67 — merge into viewhands_delta
Convert-Merged "viewhands_delta" "weapon_m67_grenade" "viewmodel_m67_merged" "viewmodel_m67_"

# 4c: MP5 — merge into viewmodel_mp5_sp_iw5 (has unique arms)
Convert-Merged "viewmodel_mp5_sp_iw5" "weapon_mp5_sp_iw5" "viewmodel_mp5_merged" "viewmodel_mp5_"

# 4d: AK47 — merge into viewmodel_ak47_tactical
Convert-Merged "viewmodel_ak47_tactical" "weapon_ak47_tactical" "viewmodel_ak47_merged" ""

# 4e: RPG7 — merge into viewmodel_rpg7
Convert-Merged "viewmodel_rpg7" "weapon_rpg7" "viewmodel_rpg7_merged" ""

# ===== PHASE 5: Compile ALL QCs =====
Write-Host "`n===== PHASE 5: Compiling $((Get-ChildItem -Recurse $outdir -Filter *.qc).Count) QCs ====="
$i = 0
foreach ($qc in (Get-ChildItem -Recurse $outdir -Filter "*.qc")) {
    $i++
    Write-Host "[$i] $($qc.Name)..."
    $prev = Get-Location
    Set-Location $outdir
    & "$outdir\studiomdl.exe" "-nop4" $qc.FullName 2>&1 | ForEach-Object { Write-Host "  $_" }
    Set-Location $prev
}
}
Write-Host "`n===== ALL DONE in $($totalTime.TotalMinutes.ToString('0.0')) minutes ====="
Write-Host "Output: $outdir"
