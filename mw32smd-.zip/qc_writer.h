#pragma once
#include "wraith_types.h"
#include <fstream>
#include <set>
#include <algorithm>
#include <cctype>

// ===========================================================================
//  QC Writer — generates GoldSrc .qc compile script
//  Features: $body, $bodygroup, $texturegroup, $bbox, $cbox, $eyeposition,
//            $hbox, $sequence, $scale, $cd, $cdtexture, render flags
// ===========================================================================
struct QCWriter {

    static std::string SanitizeName(const std::string& s, int maxLen = 32) {
        std::string out = s;
        for (char& c : out)
            if (!std::isalnum((unsigned char)c) && c != '_' && c != '-' && c != '.')
                c = '_';
        if ((int)out.size() > maxLen) out = out.substr(0, maxLen);
        return out;
    }

    static std::string ToLower(std::string s) {
        std::transform(s.begin(), s.end(), s.begin(), ::tolower);
        return s;
    }

    static std::string TexStem(const std::string& p) {
        auto pos = p.find_last_of("/\\");
        std::string file = (pos == std::string::npos) ? p : p.substr(pos + 1);
        auto dot = file.find_last_of('.');
        std::string stem = (dot == std::string::npos) ? file : file.substr(0, dot);
        if (stem.empty()) stem = "tex";
        return SanitizeName(stem, 60);
    }

    struct HBox {
        int group;
        std::string bone;
        Vec3 mn, mx;
        std::string comment;
    };

    // Auto-detect hitboxes from bone bounding boxes
    static std::vector<HBox> GenHitboxes(const SmdScene& s) {
        struct Pat { int g; const char* c; std::vector<const char*> kw; };
        static const Pat pats[] = {
            {1, "Head",       {"head","skull","cranium","neck1","Head1","Bip01_Head"}},
            {2, "Chest",      {"spine2","spine3","chest","thorax","upperchest","Spine2","Spine3"}},
            {2, "Upper Body", {"spine1","Spine1","torso","upper_torso"}},
            {3, "Stomach",    {"pelvis","hips","spine0","Spine0","stomach","abdomen","Bip01_Pelvis"}},
            {4, "Left Arm",   {"l_upperarm","leftarm","bip01_l_upperarm","LeftArm"}},
            {5, "Right Arm",  {"r_upperarm","rightarm","bip01_r_upperarm","RightArm"}},
            {4, "Left FArm",  {"l_forearm","leftforearm","bip01_l_forearm","LeftForeArm"}},
            {5, "Right FArm", {"r_forearm","rightforearm","bip01_r_forearm","RightForeArm"}},
            {4, "Left Hand",  {"l_hand","lefthand","bip01_l_hand","LeftHand"}},
            {5, "Right Hand", {"r_hand","righthand","bip01_r_hand","RightHand"}},
            {6, "Left Thigh", {"l_thigh","bip01_l_thigh","LeftUpLeg","leftupleg"}},
            {7, "Right Thigh",{"r_thigh","bip01_r_thigh","RightUpLeg","rightupleg"}},
            {6, "Left Calf",  {"l_calf","bip01_l_calf","LeftLeg","leftleg"}},
            {7, "Right Calf", {"r_calf","bip01_r_calf","RightLeg","rightleg"}},
            {6, "Left Foot",  {"l_foot","bip01_l_foot","LeftFoot"}},
            {7, "Right Foot", {"r_foot","bip01_r_foot","RightFoot"}},
        };

        std::vector<HBox> out;
        for (auto& b : s.bones) {
            if (!b.bbox.valid) continue;
            std::string lo = ToLower(b.name);
            int grp = -1; std::string cmt;
            for (auto& p : pats) {
                for (auto& kw : p.kw) {
                    if (lo.find(ToLower(kw)) != std::string::npos) { grp = p.g; cmt = p.c; break; }
                }
                if (grp >= 0) break;
            }
            if (grp < 0) continue;
            const double pad = 1.5;
            Vec3 mn = { b.bbox.mn.x - b.pos.x - pad, b.bbox.mn.y - b.pos.y - pad, b.bbox.mn.z - b.pos.z - pad };
            Vec3 mx = { b.bbox.mx.x - b.pos.x + pad, b.bbox.mx.y - b.pos.y + pad, b.bbox.mx.z - b.pos.z + pad };
            out.push_back({ grp, b.name, mn, mx, cmt });
        }
        return out;
    }

    static std::string FV(const Vec3& v) {
        char b[128];
        std::snprintf(b, sizeof(b), "%.4f %.4f %.4f", v.x, v.y, v.z);
        return b;
    }

    // Detect transparency from image data (crude check on filename patterns)
    static bool HasTransparency(const std::string& texName) {
        std::string lo = ToLower(texName);
        // Common transparency indicators in CoD texture names
        return lo.find("_mask") != std::string::npos ||
               lo.find("_alpha") != std::string::npos ||
               lo.find("_glass") != std::string::npos ||
               lo.find("_glow") != std::string::npos ||
               lo.find("_fx") != std::string::npos;
    }

    static bool IsAdditive(const std::string& texName) {
        std::string lo = ToLower(texName);
        return lo.find("_add") != std::string::npos ||
               lo.find("_glow") != std::string::npos ||
               lo.find("_flare") != std::string::npos;
    }

    static bool IsChrome(const std::string& texName) {
        std::string lo = ToLower(texName);
        return lo.find("_chrome") != std::string::npos ||
               lo.find("_spec") != std::string::npos ||
               lo.find("_env") != std::string::npos;
    }

    static bool IsFlatShade(const std::string& texName) {
        std::string lo = ToLower(texName);
        return lo.find("_flat") != std::string::npos;
    }

    static bool WriteQC(const std::string& path,
                         const std::string& baseName,
                         const SmdScene& scene,
                         const std::vector<std::string>& bodyNames,
                         const std::vector<SmdAnim>& anims,
                         const std::set<std::string>& texSet,
                         const std::string& modelDir = "models/player")
    {
        std::ofstream f(path);
        if (!f) return false;

        f << "// ================================================================\n";
        f << "//  " << baseName << ".qc\n";
        f << "//  Auto-generated by mw32smd - MW3 to GoldSrc Model Converter\n";
        f << "//  Compile with:  studiomdl.exe " << baseName << ".qc\n";
        f << "// ================================================================\n\n";

        f << "$modelname \"" << baseName << ".mdl\"\n";
        f << "$cd \".\"\n";
        f << "$cdtexture \".\"\n";
        f << "$scale 1\n\n";

        // Bounding box
        if (scene.bbox.valid) {
            auto& bb = scene.bbox;
            double h = bb.mx.z - bb.mn.z;
            Vec3 eye = { (bb.mn.x + bb.mx.x) * 0.5, (bb.mn.y + bb.mx.y) * 0.5, bb.mn.z + h * 0.9 };
            f << "$bbox " << FV(bb.mn) << "  " << FV(bb.mx) << "\n";
            double pd = h * 0.08;
            f << "$cbox " << FV({ bb.mn.x - pd, bb.mn.y - pd, bb.mn.z - pd }) << "  "
                         << FV({ bb.mx.x + pd, bb.mx.y + pd, bb.mx.z + pd }) << "\n";
            f << "$eyeposition " << FV(eye) << "\n\n";
        }

        // Body / bodygroups
        if (bodyNames.size() > 1) {
            for (size_t bi = 0; bi < bodyNames.size(); bi++) {
                f << "$bodygroup \"" << bodyNames[bi] << "\"\n{\n";
                f << "  studio \"" << bodyNames[bi] << "\"\n}\n";
            }
        } else {
            std::string bname = bodyNames.empty() ? baseName + "_ref" : bodyNames[0];
            f << "$bodygroup \"" << bname << "\"\n{\n";
            f << "  studio \"" << bname << "\"\n}\n";
        }
        f << "\n";

        // Texture group
        if (texSet.size() > 1) {
            f << "$texturegroup \"skinfamilies\"\n{\n";
            f << "  {";
            for (auto& tx : texSet) f << " \"" << tx << "\"";
            f << " }\n";
            f << "}\n\n";
        }

        // Render flags and texture references
        for (auto& tx : texSet) {
            if (HasTransparency(tx))
                f << "$texrendermode \"" << tx << "\" masked\n";
            if (IsAdditive(tx))
                f << "$texrendermode \"" << tx << "\" additive\n";
            if (IsChrome(tx))
                f << "$texrendermode \"" << tx << "\" chrome\n";
        }

        // Surface property hints (informational only — $tex is not a studiomdl command)
        for (auto& tx : texSet) {
            std::string lo = ToLower(tx);
            if (lo.find("_metal") != std::string::npos)
                f << "// surfaceprop hint: \"" << tx << "\" -> metal\n";
            if (lo.find("_wood") != std::string::npos)
                f << "// surfaceprop hint: \"" << tx << "\" -> wood\n";
            if (lo.find("_concrete") != std::string::npos || lo.find("_stone") != std::string::npos)
                f << "// surfaceprop hint: \"" << tx << "\" -> concrete\n";
            if (lo.find("_flesh") != std::string::npos || lo.find("_skin") != std::string::npos)
                f << "// surfaceprop hint: \"" << tx << "\" -> flesh\n";
        }

        // $flags
        int flags = 0;
        for (auto& tx : texSet) {
            if (IsChrome(tx))     flags |= 4;   // bit 2 = chrome
            if (IsFlatShade(tx))  flags |= 2;    // bit 1 = flatshade
        }
        // Auto-detect if model should not cast shadows (transparent materials)
        for (auto& tx : texSet) {
            if (HasTransparency(tx)) { flags |= 0x80; break; } // bit 7 = noshadow (common for glass)
        }
        if (flags) f << "$flags " << flags << "\n\n";

        // Hitboxes — GoldSrc syntax: $hbox <group> "<bone>" <minx miny minz> <maxx maxy maxz>
        auto hboxes = GenHitboxes(scene);
        if (!hboxes.empty()) {
            f << "// Auto-generated hitboxes\n";
            for (auto& hb : hboxes) {
                f << "$hbox " << hb.group << " \"" << hb.bone << "\" "
                  << FV(hb.mn) << "  " << FV(hb.mx)
                  << "  // " << hb.comment << "\n";
            }
            f << "\n";
        }

        // Sequences
        // Format: $sequence <name> <animfile> fps <rate>
        // (no body reference needed — studiomdl matches bodies by skeleton)
        std::set<std::string> usedSeqNames;
        for (auto& sa : anims) {
            std::string stem = sa.name;
            auto dot = stem.find_last_of('.');
            if (dot != std::string::npos) stem = stem.substr(0, dot);
            std::string seqName = SanitizeName(stem, 64);

            // Deduplicate sequence names (studiomdl rejects duplicates)
            std::string unique = seqName;
            int n = 1;
            while (usedSeqNames.count(unique)) unique = seqName + "_" + std::to_string(++n);
            usedSeqNames.insert(unique);

            // Reference the sanitized SMD filename (matches the file written by main)
            f << "$sequence \"" << unique << "\" \"" << seqName << "\"";
            f << " fps " << (int)sa.fps;
            if (sa.loop) f << " loop";
            f << "\n";
        }

        return true;
    }
};
