@echo off
setlocal enabledelayedexpansion

set "BASE=C:\Users\MOI\Downloads\Greyhound-source (1)\Greyhound-source (1)"
set "CONVERTER=%BASE%\mw32smd\mw32smd.exe"
set "STUDIOMDL=C:\Users\MOI\Downloads\Meshy_AI_RL_07_Rocket_Battery_0702102556_generate\studiomdl.exe"
set "XMODELS=%BASE%\Greyhound-source-code\src\WraithXCOD\x64\Release\exported_files\modern_warfare_3\xmodels"
set "XANIMS=%BASE%\Greyhound-source-code\src\WraithXCOD\x64\Release\exported_files\modern_warfare_3\xanims"
set "TEXDIR=%XMODELS%\_images"
set "OUTDIR=%BASE%\mw32smd\batch_v2"

if exist "%OUTDIR%" rmdir /s /q "%OUTDIR%"
mkdir "%OUTDIR%"
copy "%STUDIOMDL%" "%OUTDIR%\studiomdl.exe" >nul

:: Phase 1: Props, chars, vehicles
for %%m in (
    accessories_book_row01_paris bc_militarytent_wood_table body_chemwar_russian_assault_b
    body_hero_truck_delta ch_missle_rack com_airduct_02 com_bottle4
    com_cardboardbox01 com_cardboardbox01_open com_cardboardbox06 com_cardboardbox_dusty_03
    com_computer_keyboard com_office_book_beige_paper_folder com_tin_round_flat
    com_water_fount_statue_v2 defaultvehicle fx_shotgun_shell grenade_bag
    head_airborne_a head_delta_a intel_laptop ivy_vine_clump_root
    me_antenna me_rebar01 mil_ammo_case_1
    projectile_bouncing_betty_trigger projectile_cbu97_clusterbomb_shell
    projectile_cbu97_clusterbomb_tail projectile_javelin_missile projectile_m203grenade
    projectile_m67fraggrenade projectile_m84_flashbang_grenade projectile_rpg7
    projectile_tag projectile_us_smoke_grenade prop_large_generator
    prop_telephone_box tag_turret vehicle_ac130_low vehicle_cobra_helicopter_d
    vehicle_f15_missile viewhands_delta
) do (
    echo [CONVERT] %%m
    mkdir "%OUTDIR%\%%m" 2>nul
    "%CONVERTER%" --model "%XMODELS%\%%m\%%m_LOD0.semodel" --texdir "%TEXDIR%" --outdir "%OUTDIR%\%%m" --modeldir "models/player" --maxbones 128
    if !errorlevel! neq 0 echo FAILED: %%m (exit !errorlevel!)
)

:: Phase 2: Standalone weapons
for %%m in (
    weapon_aa12_sp_iw5 weapon_ak47_tactical weapon_ak47_tactical_clip
    weapon_m67_grenade weapon_mp5 weapon_mp5k_clip weapon_mp5_clip
    weapon_mp5_clip_iw5 weapon_mp5_sp_iw5 weapon_rpg7
) do (
    echo [CONVERT] %%m
    mkdir "%OUTDIR%\%%m" 2>nul
    "%CONVERTER%" --model "%XMODELS%\%%m\%%m_LOD0.semodel" --texdir "%TEXDIR%" --outdir "%OUTDIR%\%%m" --modeldir "models/player" --maxbones 128
    if !errorlevel! neq 0 echo FAILED: %%m (exit !errorlevel!)
)

:: Phase 3: Standalone viewmodels
for %%m in (
    viewmodel_ak74u_black viewmodel_desert_eagle_sp_iw5 viewmodel_m16
    viewmodel_m84 viewmodel_mp412 viewmodel_rpg7_rocket
) do (
    echo [CONVERT] %%m
    mkdir "%OUTDIR%\%%m" 2>nul
    "%CONVERTER%" --model "%XMODELS%\%%m\%%m_LOD0.semodel" --texdir "%TEXDIR%" --outdir "%OUTDIR%\%%m" --modeldir "models/player" --maxbones 128
    if !errorlevel! neq 0 echo FAILED: %%m (exit !errorlevel!)
)

echo.
echo ===== PHASE 4: Merged viewmodel+weapon =====

:: AA12
echo [MERGE] viewmodel_aa12_merged
mkdir "%OUTDIR%\viewmodel_aa12_merged" 2>nul
set "ANIMS="
for %%a in ("%XANIMS%\viewmodel_aa12_*.seanim") do set "ANIMS=!ANIMS! --anim "%%a""
"%CONVERTER%" --model "%XMODELS%\viewhands_delta\viewhands_delta_LOD0.semodel" --merge-model "%XMODELS%\weapon_aa12_sp_iw5\weapon_aa12_sp_iw5_LOD0.semodel" --attach-bone tag_weapon_left --texdir "%TEXDIR%" --outdir "%OUTDIR%\viewmodel_aa12_merged" --modeldir "models/player" --maxbones 128 %ANIMS%

:: M67
echo [MERGE] viewmodel_m67_merged
mkdir "%OUTDIR%\viewmodel_m67_merged" 2>nul
set "ANIMS="
for %%a in ("%XANIMS%\viewmodel_m67_*.seanim") do set "ANIMS=!ANIMS! --anim "%%a""
"%CONVERTER%" --model "%XMODELS%\viewhands_delta\viewhands_delta_LOD0.semodel" --merge-model "%XMODELS%\weapon_m67_grenade\weapon_m67_grenade_LOD0.semodel" --attach-bone tag_weapon_left --texdir "%TEXDIR%" --outdir "%OUTDIR%\viewmodel_m67_merged" --modeldir "models/player" --maxbones 128 %ANIMS%

:: MP5
echo [MERGE] viewmodel_mp5_merged
mkdir "%OUTDIR%\viewmodel_mp5_merged" 2>nul
set "ANIMS="
for %%a in ("%XANIMS%\viewmodel_mp5_*.seanim") do set "ANIMS=!ANIMS! --anim "%%a""
"%CONVERTER%" --model "%XMODELS%\viewmodel_mp5_sp_iw5\viewmodel_mp5_sp_iw5_LOD0.semodel" --merge-model "%XMODELS%\weapon_mp5_sp_iw5\weapon_mp5_sp_iw5_LOD0.semodel" --attach-bone tag_weapon_left --texdir "%TEXDIR%" --outdir "%OUTDIR%\viewmodel_mp5_merged" --modeldir "models/player" --maxbones 128 %ANIMS%

:: AK47
echo [MERGE] viewmodel_ak47_merged
mkdir "%OUTDIR%\viewmodel_ak47_merged" 2>nul
"%CONVERTER%" --model "%XMODELS%\viewmodel_ak47_tactical\viewmodel_ak47_tactical_LOD0.semodel" --merge-model "%XMODELS%\weapon_ak47_tactical\weapon_ak47_tactical_LOD0.semodel" --attach-bone tag_weapon_left --texdir "%TEXDIR%" --outdir "%OUTDIR%\viewmodel_ak47_merged" --modeldir "models/player" --maxbones 128

:: RPG7
echo [MERGE] viewmodel_rpg7_merged
mkdir "%OUTDIR%\viewmodel_rpg7_merged" 2>nul
"%CONVERTER%" --model "%XMODELS%\viewmodel_rpg7\viewmodel_rpg7_LOD0.semodel" --merge-model "%XMODELS%\weapon_rpg7\weapon_rpg7_LOD0.semodel" --attach-bone tag_weapon_left --texdir "%TEXDIR%" --outdir "%OUTDIR%\viewmodel_rpg7_merged" --modeldir "models/player" --maxbones 128

echo.
echo ===== PHASE 5: Compiling =====
for /f "delims=" %%q in ('dir /s /b "%OUTDIR%\*.qc"') do (
    echo [COMPILE] %%~nxq
    cd /d "%OUTDIR%"
    "%OUTDIR%\studiomdl.exe" -nop4 "%%q"
)

echo.
echo ===== DONE =====
